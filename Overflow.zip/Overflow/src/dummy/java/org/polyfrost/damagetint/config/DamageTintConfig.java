package org.polyfrost.damagetint.config;

public class DamageTintConfig {
}
