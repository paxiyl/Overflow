package org.polyfrost.damagetint.config;

public class DamageTintConfig {
    public static DamageColor color = new DamageColor(255, 0, 0, 255);

    public static class DamageColor {
        private int r, g, b, a;

        public DamageColor(int r, int g, int b, int a) {
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }

        public int getRed() { return r; }
        public int getGreen() { return g; }
        public int getBlue() { return b; }
        public int getAlpha() { return a; }
    }
}
