package org.polyfrost.overflowanimations.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;

public abstract class SimpleConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final File configFile;

    protected SimpleConfig(String fileName) {
        this.configFile = new File(Minecraft.getMinecraft().mcDataDir, "config" + File.separator + fileName);
    }

    public void initialize() {
        load();
        save();
    }

    public void save() {
        try {
            JsonObject jsonObj = new JsonObject();
            for (Field field : this.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                try {
                    Object value = field.get(this);
                    jsonObj.add(field.getName(), GSON.toJsonTree(value, field.getType()));
                } catch (Exception ignored) {
                }
            }
            for (Field field : this.getClass().getFields()) {
                try {
                    Object value = field.get(null);
                    jsonObj.add(field.getName(), GSON.toJsonTree(value, field.getType()));
                } catch (Exception ignored) {
                }
            }
            FileUtils.write(configFile, GSON.toJson(jsonObj), StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void load() {
        if (!configFile.exists()) return;
        try {
            String json = FileUtils.readFileToString(configFile, StandardCharsets.UTF_8);
            JsonObject jsonObj = new JsonParser().parse(json).getAsJsonObject();
            for (Field field : this.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                if (jsonObj.has(field.getName())) {
                    try {
                        Object value = GSON.fromJson(jsonObj.get(field.getName()), field.getType());
                        field.set(this, value);
                    } catch (Exception ignored) {
                    }
                }
            }
            for (Field field : this.getClass().getFields()) {
                if (Modifier.isStatic(field.getModifiers())) {
                    if (jsonObj.has(field.getName())) {
                        try {
                            Object value = GSON.fromJson(jsonObj.get(field.getName()), field.getType());
                            field.set(null, value);
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public File getConfigFile() {
        return configFile;
    }

    public static File getProfileFile(String fileName) {
        return new File(Minecraft.getMinecraft().mcDataDir, "config" + File.separator + fileName);
    }
}
