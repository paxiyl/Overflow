package org.polyfrost.overflowanimations;

import dulkirmod.config.Config;
import dulkirmod.config.DulkirConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLLoadCompleteEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;
import org.polyfrost.overflowanimations.gui.PleaseMigrateDulkirModGui;

@Mod(
    modid = OverflowAnimations.MODID,
    name = OverflowAnimations.NAME,
    version = OverflowAnimations.VERSION
)
public class OverflowAnimations {

    public static final String MODID = "@ID@";
    public static final String NAME = "@NAME@";
    public static final String VERSION = "@VER@";

    @Mod.Instance(MODID)
    public static OverflowAnimations INSTANCE;

    @JvmField
    public boolean isPatcherPresent = false;
    @JvmField
    public boolean doTheFunnyDulkirThing = false;
    @JvmField
    public boolean oldDulkirMod = false;
    private boolean customCrosshair = false;
    @JvmField
    public boolean isDamageTintPresent = false;
    @JvmField
    public boolean isItemPhysics = false;
    @JvmField
    public boolean isNEUPresent = false;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        OldAnimationsSettings.INSTANCE.initialize();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(CommandHandler.INSTANCE);
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        if (Loader.isModLoaded("dulkirmod")) {
            doTheFunnyDulkirThing = true;
        }
        isPatcherPresent = Loader.isModLoaded("patcher");
        customCrosshair = Loader.isModLoaded("custom-crosshair-mod");
        isDamageTintPresent = Loader.isModLoaded("damagetint");
        isItemPhysics = Loader.isModLoaded("itemphysic");
        isNEUPresent = Loader.isModLoaded("notenoughupdates");
    }

    @Mod.EventHandler
    public void onLoad(FMLLoadCompleteEvent event) {
        if (customCrosshair) {
            OldAnimationsSettings.smoothModelSneak = false;
            OldAnimationsSettings.INSTANCE.save();
            sendChat("OverflowAnimations: Custom Crosshair Mod detected. Disabling Smooth Model Sneak due to compatibility issues.");
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.START
                && Minecraft.getMinecraft().currentScreen == null
                && Minecraft.getMinecraft().theWorld != null
                && Minecraft.getMinecraft().thePlayer != null
                && doTheFunnyDulkirThing
                && !OldAnimationsSettings.didTheFunnyDulkirThingElectricBoogaloo) {
            try {
                Class.forName("dulkirmod.config.DulkirConfig");
                if (DulkirConfig.INSTANCE.customAnimations) {
                    dulkirTrollage();
                }
            } catch (ClassNotFoundException e) {
                oldDulkirMod = true;
                if (Config.INSTANCE.customAnimations) {
                    dulkirTrollage();
                }
            }
        }
    }

    private void dulkirTrollage() {
        Minecraft.getMinecraft().displayGuiScreen(new PleaseMigrateDulkirModGui());
    }

    public static void sendChat(String message) {
        if (Minecraft.getMinecraft().thePlayer == null) return;
        Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(message));
    }
}
