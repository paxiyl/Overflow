package org.polyfrost.overflowanimations.command;

import net.minecraft.client.Minecraft;
import org.polyfrost.overflowanimations.OldAnimationsSettingsGUI;

public class OldAnimationsCommand {
    public void handle() {
        Minecraft.getMinecraft().displayGuiScreen(new OldAnimationsSettingsGUI());
    }
}
