package org.polyfrost.overflowanimations.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;

@Pseudo
@Mixin(targets = "org.polyfrost.onegui.manager.config.OneConfigOption")
public class ItemCustomizeManagerMixin {
}
