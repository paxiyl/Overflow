package org.polyfrost.overflowanimations.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;

@Pseudo
@Mixin(targets = "dulkirmod.config.DulkirConfig")
public class DulkirConfigMixin {
}
