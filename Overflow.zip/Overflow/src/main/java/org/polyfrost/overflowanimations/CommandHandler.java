package org.polyfrost.overflowanimations;

import net.minecraft.client.Minecraft;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;

import java.util.ArrayList;
import java.util.List;

public class CommandHandler implements ICommand {

    @Override
    public String getCommandName() {
        return "overflowanimations";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/overflowanimations";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        Minecraft.getMinecraft().displayGuiScreen(new OldAnimationsSettingsGUI());
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public List addTabCompletionOptions(ICommandSender sender, String[] args) {
        return new ArrayList();
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
