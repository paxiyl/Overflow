package org.polyfrost.overflowanimations.mixin.interfaces;

import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@SideOnly(Side.CLIENT)
@Mixin(RenderItem.class)
public interface RenderItemInvoker {
    @Invoker("setupGuiTransform")
    void invokeSetupGuiTransform(int x, int y, boolean is3D);
}
