package org.polyfrost.overflowanimations.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.polyfrost.overflowanimations.OverflowAnimations;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;
import org.polyfrost.overflowanimations.hooks.AnimationExportUtils;

import java.io.IOException;

public class PleaseMigrateDulkirModGui extends GuiScreen {

    private GuiButton transferButton;
    private GuiButton cancelButton;

    @Override
    public void initGui() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        transferButton = new GuiButton(0, centerX - 105, centerY + 20, 100, 20, "Transfer");
        cancelButton = new GuiButton(1, centerX + 5, centerY + 20, 100, 20, "Cancel");

        this.buttonList.add(transferButton);
        this.buttonList.add(cancelButton);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button == transferButton) {
            markAsViewed();
            AnimationExportUtils.transferDulkirConfig();
            Minecraft.getMinecraft().displayGuiScreen(null);
        } else if (button == cancelButton) {
            if (cancelButton.displayString.equals("Cancel")) {
                cancelButton.displayString = "Confirm";
            } else {
                markAsViewed();
                cancelButton.displayString = "Cancel";
                Minecraft.getMinecraft().displayGuiScreen(null);
            }
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        this.drawCenteredString(this.fontRendererObj, "OverflowAnimations", centerX, centerY - 60, 0xFFFFFF);
        this.drawCenteredString(this.fontRendererObj, "OverflowAnimations now replaces DulkirMod's animations feature.", centerX, centerY - 20, 0xCCCCCC);
        this.drawCenteredString(this.fontRendererObj, "Would you like to import your DulkirMod config?", centerX, centerY, 0xCCCCCC);
        this.drawCenteredString(this.fontRendererObj, "(You can transfer your config later in the settings)", centerX, centerY + 10, 0x999999);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private void markAsViewed() {
        OverflowAnimations.doTheFunnyDulkirThing = false;
        OldAnimationsSettings.didTheFunnyDulkirThingElectricBoogaloo = true;
        OldAnimationsSettings.INSTANCE.save();
    }
}
