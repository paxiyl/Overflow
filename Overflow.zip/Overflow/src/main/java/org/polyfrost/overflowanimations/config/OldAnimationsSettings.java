package org.polyfrost.overflowanimations.config;

import org.polyfrost.overflowanimations.OverflowAnimations;
import org.polyfrost.overflowanimations.hooks.PotionColors;

public class OldAnimationsSettings extends SimpleConfig {

    // 2D Items
    public static boolean itemSprites = false;
    public static boolean itemSpritesColor = false;
    public static boolean spritesGlint = false;
    public static boolean rotationFix = true;

    // Smooth Sneaking
    public static boolean smoothSneaking = true;
    public static boolean longerUnsneak = true;
    public static boolean smoothModelSneak = true;

    // Interaction
    public static boolean oldBlockhitting = true;
    public int armorDamageTintStyle = 3;
    public int itemSwitchMode = 1;
    public static boolean visualSwing = true;
    public static boolean punching = true;
    public static boolean punchingParticles = true;

    // Positions
    public static boolean firstTransformations = true;
    public static boolean thirdTransformations = true;
    public static boolean fishingRodPosition = true;
    public static boolean firstPersonCarpetPosition = true;
    public static boolean thirdPersonCarpetPosition = true;
    public static boolean oldProjectiles = true;
    public static boolean oldArmPosition = true;
    public static boolean thirdPersonBlock = true;
    public static boolean oldXPOrbs = true;
    public static boolean oldPickup = true;

    // Enchantment Glint
    public static boolean enchantmentGlint = true;
    public static boolean enchantmentGlintGui = false;

    // Item Changes
    public static boolean fishingStick = false;

    // HUD
    public static boolean oldHealth = true;
    public int debugCrosshairMode = 2;
    public int debugScreenMode = 1;
    public int tabMode = 1;

    // Miscellaneous
    public static boolean modernPotColors = true;
    public static boolean enchantmentGlintNew = true;
    public static boolean rodBowGuiFix = true;
    public static boolean modernMovement = true;
    public static boolean modernBobbing = true;
    public static boolean modernDropSwing = true;
    public static boolean headYawFix = true;
    public static boolean funnyFidget = false;
    public static boolean modernBreak = true;
    public static boolean fireballModel = false;
    public static boolean damageTilt = false;
    public float reequipSpeed = 0.4F;
    public static boolean fixReequip = true;
    public static boolean disablePickup = false;
    public float pickupPosition = 0.0F;
    public static boolean fixRod = true;
    public float rodThickness = 0.0F;
    public static boolean breakFix = false;
    public static boolean oldItemRotations = false;
    public static boolean potionGlint = false;
    public static boolean coloredBottles = false;
    public static boolean damageHeldItems = false;
    public static boolean damageCape = false;
    public static boolean modernDropSwingFix = true;
    public static boolean entityTransforms = true;
    public static boolean adventurePunching = false;
    public static boolean adventureBlockHit = false;
    public static boolean adventureParticles = true;
    public static boolean noHurtCam = false;
    public static boolean lunarBlockhit = false;
    public static boolean lunarPositions = false;
    public static boolean dinnerBoneMode = false;
    public static boolean dinnerBoneModeEntities = false;
    public static boolean wackyArms = false;
    public static boolean fakeBlockHit = false;

    // Item Positions Customization
    public static boolean globalPositions = true;
    public float itemPositionX = 0.0F;
    public float itemPositionY = 0.0F;
    public float itemPositionZ = 0.0F;
    public float itemRotationYaw = 0.0F;
    public float itemRotationPitch = 0.0F;
    public float itemRotationRoll = 0.0F;
    public float itemScale = 0.0F;

    public float itemSwingSpeed = 0.0F;
    public float itemSwingSpeedHaste = 0.0F;
    public float itemSwingSpeedFatigue = 0.0F;
    public int swingSetting = 0;
    public static boolean ignoreHaste = false;
    public static boolean ignoreFatigue = false;

    public static boolean didTheFunnyDulkirThingElectricBoogaloo = false;

    public boolean enabled = true;

    public static final OldAnimationsSettings INSTANCE = new OldAnimationsSettings();
    public static ItemPositionAdvancedSettings advancedSettings = new ItemPositionAdvancedSettings();

    public OldAnimationsSettings() {
        super("overflowanimations.json");
    }

    public void resetAll() {
        itemPositionX = 0.0F;
        itemPositionY = 0.0F;
        itemPositionZ = 0.0F;
        itemRotationYaw = 0.0F;
        itemRotationPitch = 0.0F;
        itemRotationRoll = 0.0F;
        itemScale = 0.0F;

        advancedSettings.itemSwingPositionX = 0.0F;
        advancedSettings.itemSwingPositionY = 0.0F;
        advancedSettings.itemSwingPositionZ = 0.0F;
        itemSwingSpeed = 0.0F;
        itemSwingSpeedHaste = 0.0F;
        itemSwingSpeedFatigue = 0.0F;
        swingSetting = 0;
        ignoreHaste = false;

        advancedSettings.consumePositionX = 0.0F;
        advancedSettings.consumePositionY = 0.0F;
        advancedSettings.consumePositionZ = 0.0F;
        advancedSettings.consumeRotationYaw = 0.0F;
        advancedSettings.consumeRotationPitch = 0.0F;
        advancedSettings.consumeRotationRoll = 0.0F;
        advancedSettings.consumeScale = 0.0F;
        advancedSettings.consumeIntensity = 0.0F;
        advancedSettings.consumeSpeed = 0.0F;
        ItemPositionAdvancedSettings.shouldScaleEat = false;

        advancedSettings.blockedPositionX = 0.0F;
        advancedSettings.blockedPositionY = 0.0F;
        advancedSettings.blockedPositionZ = 0.0F;
        advancedSettings.blockedRotationYaw = 0.0F;
        advancedSettings.blockedRotationPitch = 0.0F;
        advancedSettings.blockedRotationRoll = 0.0F;
        advancedSettings.blockedScale = 0.0F;

        advancedSettings.droppedPositionX = 0.0F;
        advancedSettings.droppedPositionY = 0.0F;
        advancedSettings.droppedPositionZ = 0.0F;
        advancedSettings.droppedRotationYaw = 0.0F;
        advancedSettings.droppedRotationPitch = 0.0F;
        advancedSettings.droppedRotationRoll = 0.0F;
        advancedSettings.droppedScale = 0.0F;

        advancedSettings.projectilePositionX = 0.0F;
        advancedSettings.projectilePositionY = 0.0F;
        advancedSettings.projectilePositionZ = 0.0F;
        advancedSettings.projectileRotationYaw = 0.0F;
        advancedSettings.projectileRotationPitch = 0.0F;
        advancedSettings.projectileRotationRoll = 0.0F;
        advancedSettings.projectileScale = 0.0F;

        advancedSettings.fireballPositionX = 0.0F;
        advancedSettings.fireballPositionY = 0.0F;
        advancedSettings.fireballPositionZ = 0.0F;
        advancedSettings.fireballRotationYaw = 0.0F;
        advancedSettings.fireballRotationPitch = 0.0F;
        advancedSettings.fireballRotationRoll = 0.0F;
        advancedSettings.fireballScale = 0.0F;

        save();
    }

    public void resetItemSwingSpeed() {
        itemSwingSpeed = 0.0F;
        itemSwingSpeedHaste = 0.0F;
        itemSwingSpeedFatigue = 0.0F;
        swingSetting = 0;
        ignoreHaste = false;
        ignoreFatigue = false;
        save();
    }

    public void resetItemTransformations() {
        itemPositionX = 0.0F;
        itemPositionY = 0.0F;
        itemPositionZ = 0.0F;
        itemRotationYaw = 0.0F;
        itemRotationPitch = 0.0F;
        itemRotationRoll = 0.0F;
        itemScale = 0.0F;
        save();
    }
}
