package org.polyfrost.overflowanimations.config;

@SuppressWarnings("unused")
public class ItemPositionAdvancedSettings {

    // Swing Position Customization
    public float itemSwingPositionX = 0.0F;
    public float itemSwingPositionY = 0.0F;
    public float itemSwingPositionZ = 0.0F;

    // Eating/Drinking Position
    public float consumePositionX = 0.0F;
    public float consumePositionY = 0.0F;
    public float consumePositionZ = 0.0F;
    public float consumeRotationYaw = 0.0F;
    public float consumeRotationPitch = 0.0F;
    public float consumeRotationRoll = 0.0F;
    public float consumeScale = 0.0F;
    public float consumeIntensity = 0.0F;
    public float consumeSpeed = 0.0F;
    public static boolean shouldScaleEat = false;

    // Sword Block Position
    public float blockedPositionX = 0.0F;
    public float blockedPositionY = 0.0F;
    public float blockedPositionZ = 0.0F;
    public float blockedRotationYaw = 0.0F;
    public float blockedRotationPitch = 0.0F;
    public float blockedRotationRoll = 0.0F;
    public float blockedScale = 0.0F;

    // Dropped Item Position
    public float droppedPositionX = 0.0F;
    public float droppedPositionY = 0.0F;
    public float droppedPositionZ = 0.0F;
    public float droppedRotationYaw = 0.0F;
    public float droppedRotationPitch = 0.0F;
    public float droppedRotationRoll = 0.0F;
    public float droppedScale = 0.0F;

    // Projectiles Position
    public float projectilePositionX = 0.0F;
    public float projectilePositionY = 0.0F;
    public float projectilePositionZ = 0.0F;
    public float projectileRotationYaw = 0.0F;
    public float projectileRotationPitch = 0.0F;
    public float projectileRotationRoll = 0.0F;
    public float projectileScale = 0.0F;

    // Fireball Position
    public float fireballPositionX = 0.0F;
    public float fireballPositionY = 0.0F;
    public float fireballPositionZ = 0.0F;
    public float fireballRotationYaw = 0.0F;
    public float fireballRotationPitch = 0.0F;
    public float fireballRotationRoll = 0.0F;
    public float fireballScale = 0.0F;

    // Fishing Line Position
    public static boolean customRodLine = false;
    public float fishingLinePositionX = -0.36F;
    public float fishingLinePositionY = 0.03f;
    public float fishingLinePositionZ = 0.35f;

    public void resetSwing() {
        itemSwingPositionX = 0.0F;
        itemSwingPositionY = 0.0F;
        itemSwingPositionZ = 0.0F;
    }

    public void resetConsume() {
        consumePositionX = 0.0F;
        consumePositionY = 0.0F;
        consumePositionZ = 0.0F;
        consumeRotationYaw = 0.0F;
        consumeRotationPitch = 0.0F;
        consumeRotationRoll = 0.0F;
        consumeScale = 0.0F;
        consumeIntensity = 0.0F;
        consumeSpeed = 0.0F;
        shouldScaleEat = false;
    }

    public void resetBlocked() {
        blockedPositionX = 0.0F;
        blockedPositionY = 0.0F;
        blockedPositionZ = 0.0F;
        blockedRotationYaw = 0.0F;
        blockedRotationPitch = 0.0F;
        blockedRotationRoll = 0.0F;
        blockedScale = 0.0F;
    }

    public void resetDropped() {
        droppedPositionX = 0.0F;
        droppedPositionY = 0.0F;
        droppedPositionZ = 0.0F;
        droppedRotationYaw = 0.0F;
        droppedRotationPitch = 0.0F;
        droppedRotationRoll = 0.0F;
        droppedScale = 0.0F;
    }

    public void resetProjectile() {
        projectilePositionX = 0.0F;
        projectilePositionY = 0.0F;
        projectilePositionZ = 0.0F;
        projectileRotationYaw = 0.0F;
        projectileRotationPitch = 0.0F;
        projectileRotationRoll = 0.0F;
        projectileScale = 0.0F;
    }

    public void resetFireball() {
        fireballPositionX = 0.0F;
        fireballPositionY = 0.0F;
        fireballPositionZ = 0.0F;
        fireballRotationYaw = 0.0F;
        fireballRotationPitch = 0.0F;
        fireballRotationRoll = 0.0F;
        fireballScale = 0.0F;
    }

    public void resetFishingLine() {
        fishingLinePositionX = OldAnimationsSettings.fishingRodPosition ? -0.5f : -0.36f;
        fishingLinePositionY = 0.03f;
        fishingLinePositionZ = OldAnimationsSettings.fishingRodPosition ? 0.8f : 0.35f;
    }
}
