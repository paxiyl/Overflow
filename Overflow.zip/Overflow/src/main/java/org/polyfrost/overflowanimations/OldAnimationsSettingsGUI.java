package org.polyfrost.overflowanimations;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OldAnimationsSettingsGUI extends GuiScreen {

    private int scrollOffset = 0;
    private final List<SettingEntry> entries = new ArrayList<>();

    @Override
    public void initGui() {
        entries.clear();
        addToggle("1.7 Block-Hitting Animation", () -> OldAnimationsSettings.oldBlockhitting, v -> OldAnimationsSettings.oldBlockhitting = v);
        addToggle("1.7 Smoother Sneaking", () -> OldAnimationsSettings.smoothSneaking, v -> OldAnimationsSettings.smoothSneaking = v);
        addToggle("1.7 Longer Unsneak", () -> OldAnimationsSettings.longerUnsneak, v -> OldAnimationsSettings.longerUnsneak = v);
        addToggle("1.7 Third Person Sneaking", () -> OldAnimationsSettings.smoothModelSneak, v -> OldAnimationsSettings.smoothModelSneak = v);
        addToggle("1.7 First-Person Item Transformations", () -> OldAnimationsSettings.firstTransformations, v -> OldAnimationsSettings.firstTransformations = v);
        addToggle("1.7 Third-Person Item Transformations", () -> OldAnimationsSettings.thirdTransformations, v -> OldAnimationsSettings.thirdTransformations = v);
        addToggle("1.7 Third-Person Sword Block Position", () -> OldAnimationsSettings.thirdPersonBlock, v -> OldAnimationsSettings.thirdPersonBlock = v);
        addToggle("1.7 Enchantment Glint", () -> OldAnimationsSettings.enchantmentGlint, v -> OldAnimationsSettings.enchantmentGlint = v);
        addToggle("1.7 Health Bar Flashing", () -> OldAnimationsSettings.oldHealth, v -> OldAnimationsSettings.oldHealth = v);
        addToggle("2D Dropped Items", () -> OldAnimationsSettings.itemSprites, v -> OldAnimationsSettings.itemSprites = v);
        addToggle("1.7 Projectile Transformations", () -> OldAnimationsSettings.oldProjectiles, v -> OldAnimationsSettings.oldProjectiles = v);
        addToggle("1.20+ Potion Colors", () -> OldAnimationsSettings.modernPotColors, v -> OldAnimationsSettings.modernPotColors = v);
        addToggle("1.15+ Armor Enchantment Glint", () -> OldAnimationsSettings.enchantmentGlintNew, v -> OldAnimationsSettings.enchantmentGlintNew = v);
        addToggle("1.9+ Bow Pullback GUI Animation", () -> OldAnimationsSettings.rodBowGuiFix, v -> OldAnimationsSettings.rodBowGuiFix = v);
        addToggle("1.15+ Backwards Walk Animation", () -> OldAnimationsSettings.modernMovement, v -> OldAnimationsSettings.modernMovement = v);
        addToggle("1.14+ View Bobbing", () -> OldAnimationsSettings.modernBobbing, v -> OldAnimationsSettings.modernBobbing = v);
        addToggle("1.15+ Drop Item Arm Swing", () -> OldAnimationsSettings.modernDropSwing, v -> OldAnimationsSettings.modernDropSwing = v);
        addToggle("1.15+ Head Yaw Fix", () -> OldAnimationsSettings.headYawFix, v -> OldAnimationsSettings.headYawFix = v);
        addToggle("1.19+ Block Breaking Animation", () -> OldAnimationsSettings.modernBreak, v -> OldAnimationsSettings.modernBreak = v);
        addToggle("Damage Tilt", () -> OldAnimationsSettings.damageTilt, v -> OldAnimationsSettings.damageTilt = v);
        addToggle("Block Breaking Fixes", () -> OldAnimationsSettings.breakFix, v -> OldAnimationsSettings.breakFix = v);
        addToggle("Disable Hurt Camera Shake", () -> OldAnimationsSettings.noHurtCam, v -> OldAnimationsSettings.noHurtCam = v);
        addToggle("Dinnerbone Mode (Player)", () -> OldAnimationsSettings.dinnerBoneMode, v -> OldAnimationsSettings.dinnerBoneMode = v);
        addToggle("Dinnerbone Mode (All Entities)", () -> OldAnimationsSettings.dinnerBoneModeEntities, v -> OldAnimationsSettings.dinnerBoneModeEntities = v);
        addToggle("Global Item Position Toggle", () -> OldAnimationsSettings.globalPositions, v -> OldAnimationsSettings.globalPositions = v);

        rebuildButtons();
    }

    private void addToggle(String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
        entries.add(new SettingEntry(name, getter, setter));
    }

    private void rebuildButtons() {
        this.buttonList.clear();
        int y = 40;
        int index = 0;
        for (SettingEntry entry : entries) {
            int actualY = y - scrollOffset;
            if (actualY > 20 && actualY < this.height - 30) {
                boolean enabled = entry.getter.getAsBoolean();
                GuiButton btn = new GuiButton(index, this.width / 2 - 150, actualY, 300, 20, entry.name + ": " + (enabled ? "ON" : "OFF"));
                this.buttonList.add(btn);
            }
            y += 24;
            index++;
        }

        this.buttonList.add(new GuiButton(999, this.width / 2 - 75, this.height - 25, 150, 20, "Reset All"));
        this.buttonList.add(new GuiButton(998, this.width / 2 - 75, 5, 150, 15, "Save & Close"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 999) {
            OldAnimationsSettings.INSTANCE.resetAll();
            rebuildButtons();
            return;
        }
        if (button.id == 998) {
            OldAnimationsSettings.INSTANCE.save();
            mc.displayGuiScreen(null);
            return;
        }
        if (button.id >= 0 && button.id < entries.size()) {
            SettingEntry entry = entries.get(button.id);
            entry.setter.accept(!entry.getter.getAsBoolean());
            rebuildButtons();
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int dWheel = Mouse.getEventDWheel();
        if (dWheel != 0) {
            scrollOffset -= dWheel * 3;
            scrollOffset = Math.max(0, scrollOffset);
            rebuildButtons();
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, "OverflowAnimations Settings", this.width / 2, 10, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onGuiClosed() {
        OldAnimationsSettings.INSTANCE.save();
    }

    private static class SettingEntry {
        final String name;
        final java.util.function.BooleanSupplier getter;
        final java.util.function.Consumer<Boolean> setter;

        SettingEntry(String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
            this.name = name;
            this.getter = getter;
            this.setter = setter;
        }
    }
}
