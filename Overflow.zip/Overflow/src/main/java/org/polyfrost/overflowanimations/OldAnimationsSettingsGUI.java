package org.polyfrost.overflowanimations;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OldAnimationsSettingsGUI extends GuiScreen {

    private int selectedCategory = 0;
    private final List<Category> categories = new ArrayList<>();
    private boolean needsRebuild = true;

    @Override
    public void initGui() {
        categories.clear();

        Category items = new Category("2D Items");
        items.toggle("2D Dropped Items", () -> OldAnimationsSettings.itemSprites, v -> OldAnimationsSettings.itemSprites = v);
        items.toggle("1.7 Sprite Colors", () -> OldAnimationsSettings.itemSpritesColor, v -> OldAnimationsSettings.itemSpritesColor = v);
        items.toggle("Remove Glint From Sprites", () -> OldAnimationsSettings.spritesGlint, v -> OldAnimationsSettings.spritesGlint = v);
        items.toggle("Rotation Fix", () -> OldAnimationsSettings.rotationFix, v -> OldAnimationsSettings.rotationFix = v);
        categories.add(items);

        Category sneaking = new Category("Sneaking");
        sneaking.toggle("1.7 Smoother Sneaking", () -> OldAnimationsSettings.smoothSneaking, v -> OldAnimationsSettings.smoothSneaking = v);
        sneaking.toggle("1.7 Longer Unsneak", () -> OldAnimationsSettings.longerUnsneak, v -> OldAnimationsSettings.longerUnsneak = v);
        sneaking.toggle("1.7 Third Person Sneaking", () -> OldAnimationsSettings.smoothModelSneak, v -> OldAnimationsSettings.smoothModelSneak = v);
        categories.add(sneaking);

        Category interaction = new Category("Interaction");
        interaction.toggle("1.7 Block-Hitting", () -> OldAnimationsSettings.oldBlockhitting, v -> OldAnimationsSettings.oldBlockhitting = v);
        interaction.toggle("1.7 Miss Penalty Swing", () -> OldAnimationsSettings.visualSwing, v -> OldAnimationsSettings.visualSwing = v);
        interaction.toggle("1.7 Punching During Use", () -> OldAnimationsSettings.punching, v -> OldAnimationsSettings.punching = v);
        interaction.toggle("1.7 Punch Particles", () -> OldAnimationsSettings.punchingParticles, v -> OldAnimationsSettings.punchingParticles = v);
        interaction.dropdown("Armor Damage Tint", () -> OldAnimationsSettings.INSTANCE.armorDamageTintStyle, v -> OldAnimationsSettings.INSTANCE.armorDamageTintStyle = v, new String[]{"None", "1.7", "1.8+Glint", "1.8-Glint"});
        interaction.dropdown("Item Switch Animation", () -> OldAnimationsSettings.INSTANCE.itemSwitchMode, v -> OldAnimationsSettings.INSTANCE.itemSwitchMode = v, new String[]{"Off", "1.7", "1.8"});
        categories.add(interaction);

        Category positions = new Category("Positions");
        positions.toggle("1.7 1st-Person Items", () -> OldAnimationsSettings.firstTransformations, v -> OldAnimationsSettings.firstTransformations = v);
        positions.toggle("1.7 3rd-Person Items", () -> OldAnimationsSettings.thirdTransformations, v -> OldAnimationsSettings.thirdTransformations = v);
        positions.toggle("1.7 Fishing Rod", () -> OldAnimationsSettings.fishingRodPosition, v -> OldAnimationsSettings.fishingRodPosition = v);
        positions.toggle("1.7 Carpet (1st)", () -> OldAnimationsSettings.firstPersonCarpetPosition, v -> OldAnimationsSettings.firstPersonCarpetPosition = v);
        positions.toggle("1.7 Carpet (3rd)", () -> OldAnimationsSettings.thirdPersonCarpetPosition, v -> OldAnimationsSettings.thirdPersonCarpetPosition = v);
        positions.toggle("1.7 Projectiles", () -> OldAnimationsSettings.oldProjectiles, v -> OldAnimationsSettings.oldProjectiles = v);
        positions.toggle("1.7 Arm Block Position", () -> OldAnimationsSettings.oldArmPosition, v -> OldAnimationsSettings.oldArmPosition = v);
        positions.toggle("1.7 Sword Block (3rd)", () -> OldAnimationsSettings.thirdPersonBlock, v -> OldAnimationsSettings.thirdPersonBlock = v);
        positions.toggle("1.7 XP Orbs", () -> OldAnimationsSettings.oldXPOrbs, v -> OldAnimationsSettings.oldXPOrbs = v);
        positions.toggle("1.7 Pickup Animation", () -> OldAnimationsSettings.oldPickup, v -> OldAnimationsSettings.oldPickup = v);
        categories.add(positions);

        Category glint = new Category("Enchant Glint");
        glint.toggle("1.7 Enchantment Glint", () -> OldAnimationsSettings.enchantmentGlint, v -> OldAnimationsSettings.enchantmentGlint = v);
        glint.toggle("1.7 GUI Glint", () -> OldAnimationsSettings.enchantmentGlintGui, v -> OldAnimationsSettings.enchantmentGlintGui = v);
        glint.toggle("1.15+ Armor Glint", () -> OldAnimationsSettings.enchantmentGlintNew, v -> OldAnimationsSettings.enchantmentGlintNew = v);
        glint.toggle("Disable Potion Glint", () -> OldAnimationsSettings.potionGlint, v -> OldAnimationsSettings.potionGlint = v);
        categories.add(glint);

        Category hud = new Category("HUD");
        hud.toggle("1.7 Health Bar Flash", () -> OldAnimationsSettings.oldHealth, v -> OldAnimationsSettings.oldHealth = v);
        hud.dropdown("Debug Crosshair", () -> OldAnimationsSettings.INSTANCE.debugCrosshairMode, v -> OldAnimationsSettings.INSTANCE.debugCrosshairMode = v, new String[]{"1.7", "1.8", "1.12+"});
        hud.dropdown("Debug Screen", () -> OldAnimationsSettings.INSTANCE.debugScreenMode, v -> OldAnimationsSettings.INSTANCE.debugScreenMode = v, new String[]{"1.7", "1.8", "No BG"});
        hud.dropdown("Tab Menu", () -> OldAnimationsSettings.INSTANCE.tabMode, v -> OldAnimationsSettings.INSTANCE.tabMode = v, new String[]{"1.7", "1.8", "No Heads"});
        categories.add(hud);

        Category modern = new Category("Modern");
        modern.toggle("1.20+ Potion Colors", () -> OldAnimationsSettings.modernPotColors, v -> OldAnimationsSettings.modernPotColors = v);
        modern.toggle("1.9+ Bow/Fishing GUI", () -> OldAnimationsSettings.rodBowGuiFix, v -> OldAnimationsSettings.rodBowGuiFix = v);
        modern.toggle("1.15+ Backwards Walk", () -> OldAnimationsSettings.modernMovement, v -> OldAnimationsSettings.modernMovement = v);
        modern.toggle("1.14+ View Bobbing", () -> OldAnimationsSettings.modernBobbing, v -> OldAnimationsSettings.modernBobbing = v);
        modern.toggle("1.15+ Drop Swing", () -> OldAnimationsSettings.modernDropSwing, v -> OldAnimationsSettings.modernDropSwing = v);
        modern.toggle("1.15+ Head Yaw Fix", () -> OldAnimationsSettings.headYawFix, v -> OldAnimationsSettings.headYawFix = v);
        modern.toggle("1.9+ Item Use Cooldown", () -> OldAnimationsSettings.funnyFidget, v -> OldAnimationsSettings.funnyFidget = v);
        modern.toggle("1.19+ Block Breaking", () -> OldAnimationsSettings.modernBreak, v -> OldAnimationsSettings.modernBreak = v);
        modern.toggle("1.14+ Fireball Model", () -> OldAnimationsSettings.fireballModel, v -> OldAnimationsSettings.fireballModel = v);
        modern.toggle("1.19.4+ Damage Tilt", () -> OldAnimationsSettings.damageTilt, v -> OldAnimationsSettings.damageTilt = v);
        categories.add(modern);

        Category fixes = new Category("Fixes & QOL");
        fixes.toggle("Block Breaking Fixes", () -> OldAnimationsSettings.breakFix, v -> OldAnimationsSettings.breakFix = v);
        fixes.toggle("Disable Hand Sway", () -> OldAnimationsSettings.oldItemRotations, v -> OldAnimationsSettings.oldItemRotations = v);
        fixes.toggle("Colored Potion Bottles", () -> OldAnimationsSettings.coloredBottles, v -> OldAnimationsSettings.coloredBottles = v);
        fixes.toggle("Damage Tint Held Items", () -> OldAnimationsSettings.damageHeldItems, v -> OldAnimationsSettings.damageHeldItems = v);
        fixes.toggle("Damage Tint Capes", () -> OldAnimationsSettings.damageCape, v -> OldAnimationsSettings.damageCape = v);
        fixes.toggle("No Drop Swing in Chests", () -> OldAnimationsSettings.modernDropSwingFix, v -> OldAnimationsSettings.modernDropSwingFix = v);
        fixes.toggle("No Entity 3rd-Person Items", () -> OldAnimationsSettings.entityTransforms, v -> OldAnimationsSettings.entityTransforms = v);
        fixes.toggle("No Hurt Camera Shake", () -> OldAnimationsSettings.noHurtCam, v -> OldAnimationsSettings.noHurtCam = v);
        fixes.toggle("Fix Re-equip Animation", () -> OldAnimationsSettings.fixReequip, v -> OldAnimationsSettings.fixReequip = v);
        fixes.toggle("No Item Pickup Animation", () -> OldAnimationsSettings.disablePickup, v -> OldAnimationsSettings.disablePickup = v);
        fixes.toggle("Rod Line FOV-Based", () -> OldAnimationsSettings.fixRod, v -> OldAnimationsSettings.fixRod = v);
        fixes.toggle("1.7 Fishing Rod Texture", () -> OldAnimationsSettings.fishingStick, v -> OldAnimationsSettings.fishingStick = v);
        categories.add(fixes);

        Category fun = new Category("Fun & Misc");
        fun.toggle("Lunar Block-Hit Pos", () -> OldAnimationsSettings.lunarBlockhit, v -> OldAnimationsSettings.lunarBlockhit = v);
        fun.toggle("Lunar Item Positions", () -> OldAnimationsSettings.lunarPositions, v -> OldAnimationsSettings.lunarPositions = v);
        fun.toggle("Dinnerbone Player", () -> OldAnimationsSettings.dinnerBoneMode, v -> OldAnimationsSettings.dinnerBoneMode = v);
        fun.toggle("Dinnerbone All Entities", () -> OldAnimationsSettings.dinnerBoneModeEntities, v -> OldAnimationsSettings.dinnerBoneModeEntities = v);
        fun.toggle("Alpha/Indev Wavy Arms", () -> OldAnimationsSettings.wackyArms, v -> OldAnimationsSettings.wackyArms = v);
        fun.toggle("Click While Using Item", () -> OldAnimationsSettings.fakeBlockHit, v -> OldAnimationsSettings.fakeBlockHit = v);
        fun.toggle("No Adventure Punching", () -> OldAnimationsSettings.adventurePunching, v -> OldAnimationsSettings.adventurePunching = v);
        fun.toggle("No Adventure Block-Hit", () -> OldAnimationsSettings.adventureBlockHit, v -> OldAnimationsSettings.adventureBlockHit = v);
        fun.toggle("No Adventure Particles", () -> OldAnimationsSettings.adventureParticles, v -> OldAnimationsSettings.adventureParticles = v);
        fun.toggle("Ignore Haste Speed", () -> OldAnimationsSettings.ignoreHaste, v -> OldAnimationsSettings.ignoreHaste = v);
        fun.toggle("Ignore Fatigue Speed", () -> OldAnimationsSettings.ignoreFatigue, v -> OldAnimationsSettings.ignoreFatigue = v);
        fun.toggle("Custom Item Positions", () -> OldAnimationsSettings.globalPositions, v -> OldAnimationsSettings.globalPositions = v);
        fun.toggle("Custom Rod Line", () -> OldAnimationsSettings.advancedSettings.customRodLine, v -> OldAnimationsSettings.advancedSettings.customRodLine = v);
        categories.add(fun);

        needsRebuild = true;
    }

    private void rebuildUI() {
        this.buttonList.clear();

        int catWidth = 90;
        int catX = 5;
        int catStartY = 28;
        int catHeight = 18;
        int catGap = 2;

        for (int i = 0; i < categories.size(); i++) {
            int cy = catStartY + i * (catHeight + catGap);
            boolean selected = (i == selectedCategory);
            String label = categories.get(i).name;
            if (selected) {
                label = "> " + label + " <";
            }
            GuiButton catBtn = new GuiButton(1000 + i, catX, cy, catWidth, catHeight, label);
            this.buttonList.add(catBtn);
        }

        int panelX = catWidth + 15;
        int panelWidth = this.width - panelX - 10;
        int startY = 30;
        int btnHeight = 20;
        int btnGap = 2;

        if (selectedCategory >= 0 && selectedCategory < categories.size()) {
            Category cat = categories.get(selectedCategory);
            for (int i = 0; i < cat.settings.size(); i++) {
                SettingEntry entry = cat.settings.get(i);
                int by = startY + i * (btnHeight + btnGap);
                if (by + btnHeight > this.height - 30) break;

                String label;
                if (entry.isDropdown) {
                    label = entry.name + ": " + entry.options[entry.intGetter.getAsInt()];
                } else {
                    boolean enabled = entry.getter.getAsBoolean();
                    label = entry.name + ": " + (enabled ? "ON" : "OFF");
                }
                GuiButton btn = new GuiButton(i, panelX, by, panelWidth, btnHeight, label);
                this.buttonList.add(btn);
            }
        }

        this.buttonList.add(new GuiButton(999, this.width / 2 - 50, this.height - 25, 100, 20, "Reset"));
        this.buttonList.add(new GuiButton(998, this.width - 110, this.height - 25, 100, 20, "Save & Close"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 999) {
            OldAnimationsSettings.INSTANCE.resetAll();
            needsRebuild = true;
            return;
        }
        if (button.id == 998) {
            OldAnimationsSettings.INSTANCE.save();
            mc.displayGuiScreen(null);
            return;
        }
        if (button.id >= 1000) {
            int catIndex = button.id - 1000;
            if (catIndex != selectedCategory) {
                selectedCategory = catIndex;
                needsRebuild = true;
            }
            return;
        }
        if (button.id >= 0 && selectedCategory >= 0 && selectedCategory < categories.size()) {
            Category cat = categories.get(selectedCategory);
            if (button.id < cat.settings.size()) {
                SettingEntry entry = cat.settings.get(button.id);
                if (entry.isDropdown) {
                    int next = (entry.intGetter.getAsInt() + 1) % entry.options.length;
                    entry.intSetter.accept(next);
                } else {
                    entry.setter.accept(!entry.getter.getAsBoolean());
                }
                needsRebuild = true;
            }
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (needsRebuild) {
            rebuildUI();
            needsRebuild = false;
        }
        this.drawDefaultBackground();

        this.drawCenteredString(this.fontRendererObj, "OverflowAnimations Settings", this.width / 2, 10, 0xFFFFFF);

        int catWidth = 90;
        this.drawVerticalLine(catWidth + 12, 25, this.height - 30, 0xFF555555);

        this.drawCenteredString(this.fontRendererObj, "Reset", this.width / 2, this.height - 19, 0x888888);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onGuiClosed() {
        OldAnimationsSettings.INSTANCE.save();
    }

    private static class Category {
        final String name;
        final List<SettingEntry> settings = new ArrayList<>();

        Category(String name) {
            this.name = name;
        }

        void toggle(String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
            settings.add(new SettingEntry(name, getter, setter));
        }

        void dropdown(String name, java.util.function.IntSupplier getter, java.util.function.IntConsumer setter, String[] options) {
            settings.add(new SettingEntry(name, getter, setter, options));
        }
    }

    private static class SettingEntry {
        final String name;
        final java.util.function.BooleanSupplier getter;
        final java.util.function.Consumer<Boolean> setter;
        final boolean isDropdown;
        final java.util.function.IntSupplier intGetter;
        final java.util.function.IntConsumer intSetter;
        final String[] options;

        SettingEntry(String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
            this.name = name;
            this.getter = getter;
            this.setter = setter;
            this.isDropdown = false;
            this.intGetter = null;
            this.intSetter = null;
            this.options = null;
        }

        SettingEntry(String name, java.util.function.IntSupplier getter, java.util.function.IntConsumer setter, String[] options) {
            this.name = name;
            this.getter = null;
            this.setter = null;
            this.isDropdown = true;
            this.intGetter = getter;
            this.intSetter = setter;
            this.options = options;
        }
    }
}
