package org.polyfrost.overflowanimations;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class OldAnimationsSettingsGUI extends GuiScreen {

    private int scrollOffset = 0;
    private final List<SettingEntry> entries = new ArrayList<>();
    private boolean needsRebuild = true;

    @Override
    public void initGui() {
        entries.clear();

        // 2D Items
        addToggle("2D Dropped Items", () -> OldAnimationsSettings.itemSprites, v -> OldAnimationsSettings.itemSprites = v);
        addToggle("1.7 Item Sprite Colors", () -> OldAnimationsSettings.itemSpritesColor, v -> OldAnimationsSettings.itemSpritesColor = v);
        addToggle("Remove Glint From Sprites", () -> OldAnimationsSettings.spritesGlint, v -> OldAnimationsSettings.spritesGlint = v);
        addToggle("Rotation Fix", () -> OldAnimationsSettings.rotationFix, v -> OldAnimationsSettings.rotationFix = v);

        // Smooth Sneaking
        addToggle("1.7 Smoother Sneaking", () -> OldAnimationsSettings.smoothSneaking, v -> OldAnimationsSettings.smoothSneaking = v);
        addToggle("1.7 Longer Unsneak", () -> OldAnimationsSettings.longerUnsneak, v -> OldAnimationsSettings.longerUnsneak = v);
        addToggle("1.7 Third Person Sneaking", () -> OldAnimationsSettings.smoothModelSneak, v -> OldAnimationsSettings.smoothModelSneak = v);

        // Interaction
        addToggle("1.7 Block-Hitting Animation", () -> OldAnimationsSettings.oldBlockhitting, v -> OldAnimationsSettings.oldBlockhitting = v);
        addToggle("1.7 Miss Penalty Swing", () -> OldAnimationsSettings.visualSwing, v -> OldAnimationsSettings.visualSwing = v);
        addToggle("1.7 Punching During Usage", () -> OldAnimationsSettings.punching, v -> OldAnimationsSettings.punching = v);
        addToggle("1.7 Punch-During-Usage Particles", () -> OldAnimationsSettings.punchingParticles, v -> OldAnimationsSettings.punchingParticles = v);
        addDropdown("Armor Damage Tint Style", () -> OldAnimationsSettings.INSTANCE.armorDamageTintStyle, v -> { OldAnimationsSettings.INSTANCE.armorDamageTintStyle = v; OldAnimationsSettings.INSTANCE.save(); }, new String[]{"None", "1.7", "1.8 (With Glint)", "1.8 (Without Glint)"});
        addDropdown("Item Switching Animation", () -> OldAnimationsSettings.INSTANCE.itemSwitchMode, v -> { OldAnimationsSettings.INSTANCE.itemSwitchMode = v; OldAnimationsSettings.INSTANCE.save(); }, new String[]{"Disabled", "1.7", "1.8"});

        // Positions
        addToggle("1.7 First-Person Item Transformations", () -> OldAnimationsSettings.firstTransformations, v -> OldAnimationsSettings.firstTransformations = v);
        addToggle("1.7 Third-Person Item Transformations", () -> OldAnimationsSettings.thirdTransformations, v -> OldAnimationsSettings.thirdTransformations = v);
        addToggle("1.7 First-Person Fishing Rod Position", () -> OldAnimationsSettings.fishingRodPosition, v -> OldAnimationsSettings.fishingRodPosition = v);
        addToggle("1.7 First-Person Carpet Position", () -> OldAnimationsSettings.firstPersonCarpetPosition, v -> OldAnimationsSettings.firstPersonCarpetPosition = v);
        addToggle("1.7 Third-Person Carpet Position", () -> OldAnimationsSettings.thirdPersonCarpetPosition, v -> OldAnimationsSettings.thirdPersonCarpetPosition = v);
        addToggle("1.7 Projectiles Transformations", () -> OldAnimationsSettings.oldProjectiles, v -> OldAnimationsSettings.oldProjectiles = v);
        addToggle("1.7 Third-Person Arm Block Position", () -> OldAnimationsSettings.oldArmPosition, v -> OldAnimationsSettings.oldArmPosition = v);
        addToggle("1.7 Third-Person Sword Block Position", () -> OldAnimationsSettings.thirdPersonBlock, v -> OldAnimationsSettings.thirdPersonBlock = v);
        addToggle("1.7 XP Orbs Position", () -> OldAnimationsSettings.oldXPOrbs, v -> OldAnimationsSettings.oldXPOrbs = v);
        addToggle("1.7 Pickup Animation Position", () -> OldAnimationsSettings.oldPickup, v -> OldAnimationsSettings.oldPickup = v);

        // Enchantment Glint
        addToggle("1.7 Enchantment Glint", () -> OldAnimationsSettings.enchantmentGlint, v -> OldAnimationsSettings.enchantmentGlint = v);
        addToggle("1.7 GUI Enchantment Glint", () -> OldAnimationsSettings.enchantmentGlintGui, v -> OldAnimationsSettings.enchantmentGlintGui = v);

        // Item Changes
        addToggle("1.7 Third-Person Fishing Rod Cast Texture", () -> OldAnimationsSettings.fishingStick, v -> OldAnimationsSettings.fishingStick = v);

        // HUD
        addToggle("1.7 Health Bar Flashing", () -> OldAnimationsSettings.oldHealth, v -> OldAnimationsSettings.oldHealth = v);
        addDropdown("Debug Menu Crosshair Style", () -> OldAnimationsSettings.INSTANCE.debugCrosshairMode, v -> { OldAnimationsSettings.INSTANCE.debugCrosshairMode = v; OldAnimationsSettings.INSTANCE.save(); }, new String[]{"1.7", "1.8", "1.12+"});
        addDropdown("Debug Menu Style", () -> OldAnimationsSettings.INSTANCE.debugScreenMode, v -> { OldAnimationsSettings.INSTANCE.debugScreenMode = v; OldAnimationsSettings.INSTANCE.save(); }, new String[]{"1.7", "1.8", "Disable Background"});
        addDropdown("Tab Menu Style", () -> OldAnimationsSettings.INSTANCE.tabMode, v -> { OldAnimationsSettings.INSTANCE.tabMode = v; OldAnimationsSettings.INSTANCE.save(); }, new String[]{"1.7", "1.8", "Disable Heads"});

        // Misc - Modern
        addToggle("1.20+ Potion Colors", () -> OldAnimationsSettings.modernPotColors, v -> OldAnimationsSettings.modernPotColors = v);
        addToggle("1.15+ Armor Enchantment Glint", () -> OldAnimationsSettings.enchantmentGlintNew, v -> OldAnimationsSettings.enchantmentGlintNew = v);
        addToggle("1.9+ Bow Pullback / Fishing Cast GUI", () -> OldAnimationsSettings.rodBowGuiFix, v -> OldAnimationsSettings.rodBowGuiFix = v);
        addToggle("1.15+ Backwards Walk Animation", () -> OldAnimationsSettings.modernMovement, v -> OldAnimationsSettings.modernMovement = v);
        addToggle("1.14+ View Bobbing", () -> OldAnimationsSettings.modernBobbing, v -> OldAnimationsSettings.modernBobbing = v);
        addToggle("1.15+ Drop Item Arm Swing", () -> OldAnimationsSettings.modernDropSwing, v -> OldAnimationsSettings.modernDropSwing = v);
        addToggle("1.15+ Head Yaw Fix", () -> OldAnimationsSettings.headYawFix, v -> OldAnimationsSettings.headYawFix = v);
        addToggle("1.9+ Item Use Cooldown Animation", () -> OldAnimationsSettings.funnyFidget, v -> OldAnimationsSettings.funnyFidget = v);
        addToggle("1.19+ Block Breaking Animation", () -> OldAnimationsSettings.modernBreak, v -> OldAnimationsSettings.modernBreak = v);
        addToggle("1.14+ Fireball Model", () -> OldAnimationsSettings.fireballModel, v -> OldAnimationsSettings.fireballModel = v);
        addToggle("1.19.4+ Damage Tilt", () -> OldAnimationsSettings.damageTilt, v -> OldAnimationsSettings.damageTilt = v);

        // Misc - Fixes, QOL, Tweaks
        addToggle("Block Breaking Fixes", () -> OldAnimationsSettings.breakFix, v -> OldAnimationsSettings.breakFix = v);
        addToggle("Disable Hand View Sway", () -> OldAnimationsSettings.oldItemRotations, v -> OldAnimationsSettings.oldItemRotations = v);
        addToggle("Disable Potion Enchantment Glint", () -> OldAnimationsSettings.potionGlint, v -> OldAnimationsSettings.potionGlint = v);
        addToggle("Colored Potion Bottles", () -> OldAnimationsSettings.coloredBottles, v -> OldAnimationsSettings.coloredBottles = v);
        addToggle("Apply Damage Tint to Held Items", () -> OldAnimationsSettings.damageHeldItems, v -> OldAnimationsSettings.damageHeldItems = v);
        addToggle("Apply Damage Tint to Capes", () -> OldAnimationsSettings.damageCape, v -> OldAnimationsSettings.damageCape = v);
        addToggle("Disable Drop Swing in Chests", () -> OldAnimationsSettings.modernDropSwingFix, v -> OldAnimationsSettings.modernDropSwingFix = v);
        addToggle("Disable Entity Third-Person Items", () -> OldAnimationsSettings.entityTransforms, v -> OldAnimationsSettings.entityTransforms = v);
        addToggle("Disable Hurt Camera Shake", () -> OldAnimationsSettings.noHurtCam, v -> OldAnimationsSettings.noHurtCam = v);

        // Misc - Fun
        addToggle("Old Lunar Block-Hit Position", () -> OldAnimationsSettings.lunarBlockhit, v -> OldAnimationsSettings.lunarBlockhit = v);
        addToggle("Old Lunar Item Positions", () -> OldAnimationsSettings.lunarPositions, v -> OldAnimationsSettings.lunarPositions = v);
        addToggle("Dinnerbone Mode Player-Only", () -> OldAnimationsSettings.dinnerBoneMode, v -> OldAnimationsSettings.dinnerBoneMode = v);
        addToggle("Dinnerbone Mode All Entities", () -> OldAnimationsSettings.dinnerBoneModeEntities, v -> OldAnimationsSettings.dinnerBoneModeEntities = v);
        addToggle("Alpha/Indev Wavy Arms", () -> OldAnimationsSettings.wackyArms, v -> OldAnimationsSettings.wackyArms = v);
        addToggle("Allow Clicking While Using Item", () -> OldAnimationsSettings.fakeBlockHit, v -> OldAnimationsSettings.fakeBlockHit = v);

        // Misc - Adventure Mode
        addToggle("Disable Adventure Mode Punching", () -> OldAnimationsSettings.adventurePunching, v -> OldAnimationsSettings.adventurePunching = v);
        addToggle("Disable Adventure Block-Hit", () -> OldAnimationsSettings.adventureBlockHit, v -> OldAnimationsSettings.adventureBlockHit = v);
        addToggle("Disable Adventure Particles", () -> OldAnimationsSettings.adventureParticles, v -> OldAnimationsSettings.adventureParticles = v);

        // Misc - Re-equip & Pickup
        addToggle("Fix Re-equip Animation", () -> OldAnimationsSettings.fixReequip, v -> OldAnimationsSettings.fixReequip = v);
        addToggle("Disable Item Pickup Animation", () -> OldAnimationsSettings.disablePickup, v -> OldAnimationsSettings.disablePickup = v);
        addToggle("Rod Line Position Based on FOV", () -> OldAnimationsSettings.fixRod, v -> OldAnimationsSettings.fixRod = v);

        // Item Positions
        addToggle("Global Item Position Toggle", () -> OldAnimationsSettings.globalPositions, v -> OldAnimationsSettings.globalPositions = v);
        addToggle("Ignore Haste Swing Speed", () -> OldAnimationsSettings.ignoreHaste, v -> OldAnimationsSettings.ignoreHaste = v);
        addToggle("Ignore Mining Fatigue Speed", () -> OldAnimationsSettings.ignoreFatigue, v -> OldAnimationsSettings.ignoreFatigue = v);
        addToggle("Custom Fishing Rod Line Position", () -> OldAnimationsSettings.advancedSettings.customRodLine, v -> OldAnimationsSettings.advancedSettings.customRodLine = v);

        needsRebuild = true;
    }

    private void addToggle(String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
        entries.add(new SettingEntry(name, getter, setter));
    }

    private void addDropdown(String name, java.util.function.IntSupplier getter, java.util.function.IntConsumer setter, String[] options) {
        entries.add(new SettingEntry(name, getter, setter, options));
    }

    private void rebuildButtons() {
        this.buttonList.clear();
        int y = 40;
        int index = 0;
        for (SettingEntry entry : entries) {
            int actualY = y - scrollOffset;
            if (actualY > 20 && actualY < this.height - 30) {
                String label;
                if (entry.isDropdown) {
                    label = entry.name + ": " + entry.options[entry.intGetter.getAsInt()];
                } else {
                    boolean enabled = entry.getter.getAsBoolean();
                    label = entry.name + ": " + (enabled ? "ON" : "OFF");
                }
                GuiButton btn = new GuiButton(index, this.width / 2 - 150, actualY, 300, 20, label);
                this.buttonList.add(btn);
            }
            y += 24;
            index++;
        }

        this.buttonList.add(new GuiButton(999, this.width / 2 - 75, this.height - 25, 150, 20, "Reset All"));
        this.buttonList.add(new GuiButton(998, this.width / 2 - 75, 5, 150, 15, "Save & Close"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 999) {
            OldAnimationsSettings.INSTANCE.resetAll();
            scrollOffset = 0;
            needsRebuild = true;
            return;
        }
        if (button.id == 998) {
            OldAnimationsSettings.INSTANCE.save();
            mc.displayGuiScreen(null);
            return;
        }
        if (button.id >= 0 && button.id < entries.size()) {
            SettingEntry entry = entries.get(button.id);
            if (entry.isDropdown) {
                int next = (entry.intGetter.getAsInt() + 1) % entry.options.length;
                entry.intSetter.accept(next);
            } else {
                entry.setter.accept(!entry.getter.getAsBoolean());
            }
            needsRebuild = true;
        }
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int dWheel = Mouse.getEventDWheel();
        if (dWheel != 0) {
            scrollOffset -= dWheel * 3;
            scrollOffset = Math.max(0, scrollOffset);
            needsRebuild = true;
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (needsRebuild) {
            rebuildButtons();
            needsRebuild = false;
        }
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRendererObj, "OverflowAnimations Settings", this.width / 2, 10, 0xFFFFFF);
        this.drawCenteredString(this.fontRendererObj, "Scroll to see more settings", this.width / 2, this.height - 12, 0x888888);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void onGuiClosed() {
        OldAnimationsSettings.INSTANCE.save();
    }

    private static class SettingEntry {
        final String name;
        final java.util.function.BooleanSupplier getter;
        final java.util.function.Consumer<Boolean> setter;
        final boolean isDropdown;
        final java.util.function.IntSupplier intGetter;
        final java.util.function.IntConsumer intSetter;
        final String[] options;

        SettingEntry(String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
            this.name = name;
            this.getter = getter;
            this.setter = setter;
            this.isDropdown = false;
            this.intGetter = null;
            this.intSetter = null;
            this.options = null;
        }

        SettingEntry(String name, java.util.function.IntSupplier getter, java.util.function.IntConsumer setter, String[] options) {
            this.name = name;
            this.getter = null;
            this.setter = null;
            this.isDropdown = true;
            this.intGetter = getter;
            this.intSetter = setter;
            this.options = options;
        }
    }
}
