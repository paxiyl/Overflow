package org.polyfrost.overflowanimations.hooks;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import org.polyfrost.overflowanimations.OverflowAnimations;

import java.lang.reflect.Method;

public class HitColorHook {

    private static boolean damageTintClassFailed = false;
    private static Method getRed, getGreen, getBlue, getAlpha;
    private static Object colorInstance;
    private static boolean initialized = false;

    private static void initReflection() {
        if (initialized) return;
        initialized = true;
        try {
            Class<?> configClass = Class.forName("org.polyfrost.damagetint.config.DamageTintConfig");
            Object configColor = configClass.getField("color").get(null);
            Class<?> colorClass = configColor.getClass();
            getRed = colorClass.getMethod("getRed");
            getGreen = colorClass.getMethod("getGreen");
            getBlue = colorClass.getMethod("getBlue");
            getAlpha = colorClass.getMethod("getAlpha");
            colorInstance = configColor;
        } catch (Exception e) {
            damageTintClassFailed = true;
        }
    }

    public static void renderHitColorPre(EntityLivingBase entitylivingbaseIn, boolean bl, float partialTicks) {
        float f12 = entitylivingbaseIn.getBrightness(partialTicks);

        float red = f12;
        float green = 0.0F;
        float blue = 0.0F;
        float alpha = 0.4F;

        if (OverflowAnimations.isDamageTintPresent) {
            initReflection();
            if (!damageTintClassFailed && colorInstance != null) {
                try {
                    red = ((Number) getRed.invoke(colorInstance)).floatValue() / 255.0F;
                    green = ((Number) getGreen.invoke(colorInstance)).floatValue() / 255.0F;
                    blue = ((Number) getBlue.invoke(colorInstance)).floatValue() / 255.0F;
                    alpha = ((Number) getAlpha.invoke(colorInstance)).floatValue() / 255.0F;
                } catch (Exception ignored) {
                }
            }
        }

        Minecraft.getMinecraft().entityRenderer.disableLightmap();
        if (bl) {
            GlStateManager.disableTexture2D();
            GlStateManager.disableAlpha();
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            GlStateManager.depthFunc(514);
            GlStateManager.color(red, green, blue, alpha);
        }
    }

    public static void renderHitColorPost(boolean bl) {
        if (bl) {
            GlStateManager.depthFunc(515);
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.enableTexture2D();
        }
        Minecraft.getMinecraft().entityRenderer.enableLightmap();
    }

}
