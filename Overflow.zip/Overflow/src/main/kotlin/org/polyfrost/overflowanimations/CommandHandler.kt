package org.polyfrost.overflowanimations

import net.minecraft.client.Minecraft
import net.minecraft.command.ICommand
import net.minecraft.command.ICommandSender

object CommandHandler : ICommand {
    override fun getCommandName(): String = "overflowanimations"
    override fun getCommandUsage(sender: ICommandSender?): String = "/overflowanimations"
    override fun processCommand(sender: ICommandSender?, args: Array<out String>?) {
        Minecraft.getMinecraft().displayGuiScreen(OldAnimationsSettingsGUI())
    }
    override fun canCommandSenderUseCommand(sender: ICommandSender?): Boolean = true
    override fun addAliases(aliases: MutableList<String>?) {
        aliases?.add("oam")
        aliases?.add("oldanimations")
        aliases?.add("animations")
    }
}
