# Build the patched Pojav version

This fork is configured so the **mod bytecode targets Java 8**. The GitHub Actions workflow uses JDK 17 only to run the modern Gradle build tooling.

1. Create an empty GitHub repository.
2. Upload the contents of this project to it.
3. Open **Actions → Build OverflowAnimations → Run workflow**.
4. When it completes, open the workflow run and download the `OverflowAnimations-Pojav-Java8` artifact.

The workflow also checks one produced class file and requires class-file major version **52**, which corresponds to Java 8.

Expected build task:

    ./gradlew :1.8.9-forge:build --no-daemon --stacktrace
