# OverflowAnimations Pojav / Java 8 audit

## Result
The project is configured for Minecraft 1.8.9 and is intended to emit Java 8 bytecode. The build has been hardened to force Java/Kotlin output to JVM 1.8 even when the build machine uses a newer JDK.

A functional final JAR could **not** be produced in this environment because Gradle and the Minecraft/Forge/Polyfrost dependencies are not cached here and outbound network access is blocked. No fake/prebuilt JAR is included.

## Changes made

1. **Explicit Java 8 bytecode target**
   - `JavaCompile` source/target set to `1.8`.
   - Kotlin `jvmTarget` set to `1.8`.
   - Existing resource processing already uses Java 8 / `JAVA_8` for Minecraft versions before 1.17.

2. **Removed hard Dulkir compile dependency**
   - `AnimationExportUtils` previously referenced Dulkir config classes directly even though the Gradle build no longer declares Dulkir.
   - Dulkir transfer now resolves the config class/methods reflectively only when that feature is actually used.
   - The existing Dulkir compatibility mixin remains `@Pseudo`, so Dulkir is optional at launch.

3. **Removed hard Swing/AWT startup dependency**
   - The coremod duplicate-mod detector no longer imports/uses Swing UI classes.
   - Clipboard support in `AnimationExportUtils` uses reflection, so absence of desktop AWT on Android/Pojav does not stop class loading; clipboard failures fall back to console output.

4. **Removed Java/Kotlin newer enum API usage**
   - Replaced Kotlin `Enum.entries` usage with `.values()` in the 1.8.9 path.

5. **Fixed a possible null dereference**
   - `RenderItemMixin.renderEffect` now checks `overflowanimations$stack != null` before calling `getItem()`.

6. **Made the expected multi-version project directory explicit**
   - Added `versions/1.8.9/.gitkeep`, matching the directory expected by `settings.gradle.kts`.

## Remaining runtime consideration

The mod deliberately exits (`System.exit(1)`) if it detects the old `sk1er_old_animations` mod. That is conflict protection rather than a Java 17 issue. On Pojav, a conflicting old-animation jar should be removed before launching this fork.

## Build limitation in this session

The repository's Gradle wrapper is Gradle 8.8, but the wrapper distribution and build dependencies are not locally cached. The environment cannot reach the Gradle/Maven repositories, so a real `build/remapJar` cannot be completed here.

The important distinction is: **the build tool can run on a modern JDK; the generated 1.8.9 mod bytecode is explicitly targeted to Java 8.**
