package org.polyfrost.overflowanimations

import net.minecraft.client.Minecraft
import net.minecraftforge.client.ClientCommandHandler
import net.minecraftforge.common.MinecraftForge
import net.minecraftforge.fml.common.Loader
import net.minecraftforge.fml.common.Mod
import net.minecraftforge.fml.common.event.FMLInitializationEvent
import net.minecraftforge.fml.common.event.FMLLoadCompleteEvent
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent
import org.polyfrost.overflowanimations.command.OldAnimationsCommand
import org.polyfrost.overflowanimations.config.OldAnimationsSettings

/**
 * Main mod object — OneConfig dependency completely removed.
 * Config is now a plain JSON file; command uses vanilla Forge ClientCommandHandler.
 */
@Mod(
    modid = OverflowAnimations.MODID,
    name = OverflowAnimations.NAME,
    version = OverflowAnimations.VERSION,
    clientSideOnly = true
)
object OverflowAnimations {

    const val MODID: String = "@ID@"
    const val NAME: String = "@NAME@"
    const val VERSION: String = "@VER@"

    @JvmField var isPatcherPresent: Boolean = false
    @JvmField var doTheFunnyDulkirThing = false
    @JvmField var oldDulkirMod: Boolean = false
    @JvmField var isDamageTintPresent: Boolean = false
    @JvmField var isItemPhysics: Boolean = false
    @JvmField var isNEUPresent: Boolean = false

    @Mod.EventHandler
    fun init(event: FMLInitializationEvent) {
        // Load config from disk
        OldAnimationsSettings.INSTANCE.preload()
        // Register the in-game command
        ClientCommandHandler.instance.registerCommand(OldAnimationsCommand())
        // Register Forge event bus listeners (the object itself handles events via @SubscribeEvent)
        MinecraftForge.EVENT_BUS.register(this)
    }

    @Mod.EventHandler
    fun postInit(event: FMLPostInitializationEvent) {
        if (Loader.isModLoaded("dulkirmod")) {
            doTheFunnyDulkirThing = true
        }
        isPatcherPresent      = Loader.isModLoaded("patcher")
        isDamageTintPresent   = Loader.isModLoaded("damagetint")
        isItemPhysics         = Loader.isModLoaded("itemphysic")
        isNEUPresent          = Loader.isModLoaded("notenoughupdates")
    }

    @Mod.EventHandler
    fun onLoad(event: FMLLoadCompleteEvent) {
        // Custom-crosshair compat: disable smoothModelSneak just like the original
        if (Loader.isModLoaded("custom-crosshair-mod")) {
            OldAnimationsSettings.smoothModelSneak = false
            OldAnimationsSettings.save()
            println("[OverflowAnimations] Custom Crosshair Mod detected — Smooth Model Sneak disabled.")
        }
    }
}
