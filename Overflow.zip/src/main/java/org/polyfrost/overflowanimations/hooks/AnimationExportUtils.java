package org.polyfrost.overflowanimations.hooks;

import com.google.gson.Gson;
import org.polyfrost.overflowanimations.OverflowAnimations;
import org.polyfrost.overflowanimations.config.ItemPositionAdvancedSettings;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;

import java.util.Base64;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Export / import item-position presets as Base64 JSON strings.
 * OneConfig Notifications + ConfigUtils removed; no-op replacements used.
 */
public class AnimationExportUtils {

    private static final Gson GSON = new Gson();

    // ── helpers ───────────────────────────────────────────────────────────────

    /** Print a message to the Minecraft chat HUD (or console as fallback). */
    private static void notify(String msg) {
        try {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
            if (mc.thePlayer != null) {
                mc.thePlayer.addChatMessage(new net.minecraft.util.ChatComponentText(
                        "\u00a7b[OverflowAnimations]\u00a7r " + msg));
            } else {
                System.out.println("[OverflowAnimations] " + msg);
            }
        } catch (Exception e) {
            System.out.println("[OverflowAnimations] " + msg);
        }
    }

    // ── export ────────────────────────────────────────────────────────────────

    public static void exportItemPositions() {
        String string = Base64.getEncoder().encodeToString(GSON.toJson(new OverflowConfigData()).getBytes());
        try {
            setClipboardString(string);
            notify("Exported item positions to clipboard.");
        } catch (Exception e) {
            System.out.println("[OverflowAnimations] Export string: " + string);
            notify("Export written to console (clipboard unavailable).");
        }
    }

    private static void setClipboardString(String text) throws Exception {
        Class<?> toolkitClass = Class.forName("java.awt.Toolkit");
        Object toolkit = toolkitClass.getMethod("getDefaultToolkit").invoke(null);
        Object clipboard = toolkitClass.getMethod("getSystemClipboard").invoke(toolkit);

        Class<?> selectionClass = Class.forName("java.awt.datatransfer.StringSelection");
        Object selection = selectionClass.getConstructor(String.class).newInstance(text);
        Class<?> transferableClass = Class.forName("java.awt.datatransfer.Transferable");
        Class<?> clipboardOwnerClass = Class.forName("java.awt.datatransfer.ClipboardOwner");
        clipboard.getClass().getMethod("setContents", transferableClass, clipboardOwnerClass)
                .invoke(clipboard, selection, selection);
    }

    private static String getClipboardString() throws Exception {
        Class<?> toolkitClass = Class.forName("java.awt.Toolkit");
        Object toolkit = toolkitClass.getMethod("getDefaultToolkit").invoke(null);
        Object clipboard = toolkitClass.getMethod("getSystemClipboard").invoke(toolkit);

        Class<?> dataFlavorClass = Class.forName("java.awt.datatransfer.DataFlavor");
        Object stringFlavor = dataFlavorClass.getField("stringFlavor").get(null);
        Class<?> flavorClass = Class.forName("java.awt.datatransfer.DataFlavor");
        return (String) clipboard.getClass().getMethod("getData", flavorClass)
                .invoke(clipboard, stringFlavor);
    }

    // ── import ────────────────────────────────────────────────────────────────

    public static void importItemPositions() {
        try {
            String base64 = getClipboardString();
            String jsonString = new String(Base64.getDecoder().decode(base64));
            if (jsonString.contains("ignoreHaste")) {
                System.out.println("[OverflowAnimations] Detected DulkirMod config data, trying to import");
                try {
                    DulkirConfigData importSettings = GSON.fromJson(jsonString, DulkirConfigData.class);
                    importDulkir(importSettings);
                } catch (Exception e) {
                    e.printStackTrace();
                    notify("Failed to import — invalid clipboard data!");
                }
            }
            System.out.println("[OverflowAnimations] Detected OverflowAnimations config data, trying to import");
            try {
                OverflowConfigData importSettings = GSON.fromJson(jsonString, OverflowConfigData.class);
                importOverflow(importSettings);
            } catch (Exception ignored) {
                notify("Failed to import — invalid clipboard data!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            notify("Failed to decode clipboard data.");
        }
    }

    // ── apply ─────────────────────────────────────────────────────────────────

    public static void importOverflow(OverflowConfigData importSettings) {
        ItemPositionAdvancedSettings advanced = OldAnimationsSettings.advancedSettings;
        OldAnimationsSettings.itemPositionX = importSettings.itemPositionX;
        OldAnimationsSettings.itemPositionY = importSettings.itemPositionY;
        OldAnimationsSettings.itemPositionZ = importSettings.itemPositionZ;
        OldAnimationsSettings.itemRotationYaw = importSettings.itemRotationYaw;
        OldAnimationsSettings.itemRotationPitch = importSettings.itemRotationPitch;
        OldAnimationsSettings.itemRotationRoll = importSettings.itemRotationRoll;
        OldAnimationsSettings.itemScale = importSettings.itemScale;
        advanced.itemSwingPositionX = importSettings.itemSwingPositionX;
        advanced.itemSwingPositionY = importSettings.itemSwingPositionY;
        advanced.itemSwingPositionZ = importSettings.itemSwingPositionZ;
        OldAnimationsSettings.itemSwingSpeed = importSettings.itemSwingSpeed;
        OldAnimationsSettings.itemSwingSpeedHaste = importSettings.itemSwingSpeedHaste;
        OldAnimationsSettings.itemSwingSpeedFatigue = importSettings.itemSwingSpeedFatigue;
        OldAnimationsSettings.swingSetting = importSettings.shouldScaleSwing ? 1 : 0;
        advanced.consumePositionX = importSettings.consumePositionX;
        advanced.consumePositionY = importSettings.consumePositionY;
        advanced.consumePositionZ = importSettings.consumePositionZ;
        advanced.consumeRotationYaw = importSettings.consumeRotationYaw;
        advanced.consumeRotationPitch = importSettings.consumeRotationPitch;
        advanced.consumeRotationRoll = importSettings.consumeRotationRoll;
        advanced.consumeScale = importSettings.consumeScale;
        advanced.consumeIntensity = importSettings.consumeIntensity;
        advanced.consumeSpeed = importSettings.consumeSpeed;
        ItemPositionAdvancedSettings.shouldScaleEat = importSettings.shouldScaleEat;
        advanced.blockedPositionX = importSettings.blockedPositionX;
        advanced.blockedPositionY = importSettings.blockedPositionY;
        advanced.blockedPositionZ = importSettings.blockedPositionZ;
        advanced.blockedRotationYaw = importSettings.blockedRotationYaw;
        advanced.blockedRotationPitch = importSettings.blockedRotationPitch;
        advanced.blockedRotationRoll = importSettings.blockedRotationRoll;
        advanced.blockedScale = importSettings.blockedScale;
        advanced.projectilePositionX = importSettings.projectilePositionX;
        advanced.projectilePositionY = importSettings.projectilePositionY;
        advanced.projectilePositionZ = importSettings.projectilePositionZ;
        advanced.projectileRotationYaw = importSettings.projectileRotationYaw;
        advanced.projectileRotationPitch = importSettings.projectileRotationPitch;
        advanced.projectileRotationRoll = importSettings.projectileRotationRoll;
        advanced.projectileScale = importSettings.projectileScale;
        OldAnimationsSettings.save();
    }

    public static void importDulkir(DulkirConfigData importSettings) {
        ItemPositionAdvancedSettings advanced = OldAnimationsSettings.advancedSettings;
        OldAnimationsSettings.itemPositionX = importSettings.getX();
        OldAnimationsSettings.itemPositionY = importSettings.getY();
        OldAnimationsSettings.itemPositionZ = importSettings.getZ();
        OldAnimationsSettings.itemRotationYaw = importSettings.getYaw();
        OldAnimationsSettings.itemRotationPitch = importSettings.getPitch();
        OldAnimationsSettings.itemRotationRoll = importSettings.getRoll();
        OldAnimationsSettings.itemScale = importSettings.getSize();
        OldAnimationsSettings.itemSwingSpeed = importSettings.getSpeed();
        OldAnimationsSettings.itemSwingSpeedHaste = importSettings.getSpeed();
        OldAnimationsSettings.itemSwingSpeedFatigue = importSettings.getSpeed();
        OldAnimationsSettings.ignoreHaste = importSettings.getIgnoreHaste();
        OldAnimationsSettings.swingSetting = importSettings.getScaleSwing() ? 1 : 0;
        ItemPositionAdvancedSettings.shouldScaleEat = importSettings.getDrinkingFix() == 2;
        OldAnimationsSettings.save();
    }

    public static void transferDulkirConfig() {
        try {
            importDulkirConfig();
        } catch (Exception e) {
            e.printStackTrace();
            notify("Failed to transfer DulkirMod config.");
        }
    }

    private static void importDulkirConfig() throws Exception {
        // Keep Dulkir optional: Pojav users do not need Dulkir installed just to load the mod.
        String[] configClasses = OverflowAnimations.oldDulkirMod
                ? new String[]{"dulkirmod.config.Config", "dulkirmod.config.DulkirConfig"}
                : new String[]{"dulkirmod.config.DulkirConfig", "dulkirmod.config.Config"};

        Class<?> configClass = null;
        for (String name : configClasses) {
            try {
                configClass = Class.forName(name);
                break;
            } catch (ClassNotFoundException ignored) {
                // Try the alternate Dulkir config class name.
            }
        }
        if (configClass == null) {
            throw new ClassNotFoundException("DulkirMod config class was not found");
        }

        Field instanceField = configClass.getField("INSTANCE");
        Object instance = instanceField.get(null);

        DulkirConfigData data = new DulkirConfigData(
                number(instance, "getCustomSize").floatValue(),
                (Boolean) invoke(instance, "getDoesScaleSwing"),
                number(instance, "getCustomX").floatValue(),
                number(instance, "getCustomY").floatValue(),
                number(instance, "getCustomZ").floatValue(),
                number(instance, "getCustomYaw").floatValue(),
                number(instance, "getCustomPitch").floatValue(),
                number(instance, "getCustomRoll").floatValue(),
                number(instance, "getCustomSpeed").floatValue(),
                (Boolean) invoke(instance, "getIgnoreHaste"),
                number(instance, "getDrinkingSelector").intValue()
        );

        importDulkir(data);
        try { invoke(instance, "setCustomAnimations", false); } catch (Exception ignored) {}
        notify("Successfully imported DulkirMod config!");
    }

    private static Object invoke(Object instance, String methodName, Object... args) throws Exception {
        Class<?>[] types = new Class<?>[args.length];
        for (int i = 0; i < args.length; i++) {
            types[i] = args[i] instanceof Boolean ? boolean.class : args[i].getClass();
        }
        Method method = instance.getClass().getMethod(methodName, types);
        return method.invoke(instance, args);
    }

    private static Number number(Object instance, String methodName) throws Exception {
        return (Number) invoke(instance, methodName);
    }
}
