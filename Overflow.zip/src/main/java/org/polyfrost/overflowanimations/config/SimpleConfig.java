package org.polyfrost.overflowanimations.config;

import com.google.gson.*;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.FMLCommonHandler;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Lightweight config system that replaces OneConfig.
 * Reads/writes a JSON file in .minecraft/config/<name>.json
 * No external dependencies required.
 */
public class SimpleConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final File configFile;

    public SimpleConfig(String fileName) {
        File configDir = new File(Minecraft.getMinecraft().mcDataDir, "config");
        if (!configDir.exists()) configDir.mkdirs();
        this.configFile = new File(configDir, fileName);
    }

    /** Load fields from JSON into this object instance. */
    public void load() {
        if (!configFile.exists()) {
            save(); // write defaults on first run
            return;
        }
        try (Reader reader = new FileReader(configFile)) {
            JsonObject obj = new JsonParser().parse(reader).getAsJsonObject();
            for (Field field : getClass().getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) continue;
                field.setAccessible(true);
                if (!obj.has(field.getName())) continue;
                JsonElement el = obj.get(field.getName());
                try {
                    Class<?> type = field.getType();
                    if (type == boolean.class || type == Boolean.class)   field.set(this, el.getAsBoolean());
                    else if (type == int.class || type == Integer.class)  field.set(this, el.getAsInt());
                    else if (type == float.class || type == Float.class)  field.set(this, el.getAsFloat());
                    else if (type == double.class || type == Double.class) field.set(this, el.getAsDouble());
                    else if (type == String.class)                         field.set(this, el.getAsString());
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            System.err.println("[OverflowAnimations] Failed to load config: " + e.getMessage());
        }
    }

    /** Save all non-static, non-final fields of this object to JSON. */
    public void save() {
        JsonObject obj = new JsonObject();
        for (Field field : getClass().getDeclaredFields()) {
            if (Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) continue;
            field.setAccessible(true);
            try {
                Class<?> type = field.getType();
                Object val = field.get(this);
                if (type == boolean.class || type == Boolean.class)    obj.addProperty(field.getName(), (Boolean) val);
                else if (type == int.class || type == Integer.class)   obj.addProperty(field.getName(), (Integer) val);
                else if (type == float.class || type == Float.class)   obj.addProperty(field.getName(), (Float) val);
                else if (type == double.class || type == Double.class) obj.addProperty(field.getName(), (Double) val);
                else if (type == String.class)                          obj.addProperty(field.getName(), (String) val);
            } catch (Exception ignored) {}
        }
        try (Writer writer = new FileWriter(configFile)) {
            GSON.toJson(obj, writer);
        } catch (Exception e) {
            System.err.println("[OverflowAnimations] Failed to save config: " + e.getMessage());
        }
    }

    /** Load static fields from a separate JSON chunk stored alongside instance fields. */
    public static void loadStatics(Class<?> clazz, File configFile) {
        if (!configFile.exists()) return;
        try (Reader reader = new FileReader(configFile)) {
            JsonObject root = new JsonParser().parse(reader).getAsJsonObject();
            JsonObject statics = root.has("_static") ? root.getAsJsonObject("_static") : null;
            if (statics == null) return;
            for (Field field : clazz.getDeclaredFields()) {
                if (!Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) continue;
                field.setAccessible(true);
                if (!statics.has(field.getName())) continue;
                JsonElement el = statics.get(field.getName());
                try {
                    Class<?> type = field.getType();
                    if (type == boolean.class || type == Boolean.class)    field.set(null, el.getAsBoolean());
                    else if (type == int.class || type == Integer.class)   field.set(null, el.getAsInt());
                    else if (type == float.class || type == Float.class)   field.set(null, el.getAsFloat());
                    else if (type == double.class || type == Double.class) field.set(null, el.getAsDouble());
                    else if (type == String.class)                          field.set(null, el.getAsString());
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            System.err.println("[OverflowAnimations] Failed to load static config: " + e.getMessage());
        }
    }

    public static void saveStatics(Class<?> clazz, File configFile) {
        // Read existing file first to avoid clobbering instance fields
        JsonObject root = new JsonObject();
        if (configFile.exists()) {
            try (Reader reader = new FileReader(configFile)) {
                root = new JsonParser().parse(reader).getAsJsonObject();
            } catch (Exception ignored) {}
        }
        JsonObject statics = new JsonObject();
        for (Field field : clazz.getDeclaredFields()) {
            if (!Modifier.isStatic(field.getModifiers()) || Modifier.isFinal(field.getModifiers())) continue;
            field.setAccessible(true);
            try {
                Class<?> type = field.getType();
                Object val = field.get(null);
                if (type == boolean.class || type == Boolean.class)    statics.addProperty(field.getName(), (Boolean) val);
                else if (type == int.class || type == Integer.class)   statics.addProperty(field.getName(), (Integer) val);
                else if (type == float.class || type == Float.class)   statics.addProperty(field.getName(), (Float) val);
                else if (type == double.class || type == Double.class) statics.addProperty(field.getName(), (Double) val);
                else if (type == String.class)                          statics.addProperty(field.getName(), (String) val);
            } catch (Exception ignored) {}
        }
        root.add("_static", statics);
        try (Writer writer = new FileWriter(configFile)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(root, writer);
        } catch (Exception e) {
            System.err.println("[OverflowAnimations] Failed to save static config: " + e.getMessage());
        }
    }
}
