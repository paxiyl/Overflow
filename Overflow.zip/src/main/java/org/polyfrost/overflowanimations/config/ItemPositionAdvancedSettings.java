package org.polyfrost.overflowanimations.config;

/**
 * Advanced sub-settings for item positions.
 * OneConfig annotations removed — values are read/written by OldAnimationsSettings JSON serialization.
 */
@SuppressWarnings("unused")
public class ItemPositionAdvancedSettings {

    // Swing Position
    public float itemSwingPositionX = 0.0F;
    public float itemSwingPositionY = 0.0F;
    public float itemSwingPositionZ = 0.0F;

    // Eating/Drinking Position
    public float consumePositionX = 0.0F;
    public float consumePositionY = 0.0F;
    public float consumePositionZ = 0.0F;
    public float consumeRotationYaw = 0.0F;
    public float consumeRotationPitch = 0.0F;
    public float consumeRotationRoll = 0.0F;
    public float consumeScale = 0.0F;
    public float consumeIntensity = 0.0F;
    public float consumeSpeed = 0.0F;
    public static boolean shouldScaleEat = false;

    // Sword Block Position
    public float blockedPositionX = 0.0F;
    public float blockedPositionY = 0.0F;
    public float blockedPositionZ = 0.0F;
    public float blockedRotationYaw = 0.0F;
    public float blockedRotationPitch = 0.0F;
    public float blockedRotationRoll = 0.0F;
    public float blockedScale = 0.0F;

    // Dropped Item Position
    public float droppedPositionX = 0.0F;
    public float droppedPositionY = 0.0F;
    public float droppedPositionZ = 0.0F;
    public float droppedRotationYaw = 0.0F;
    public float droppedRotationPitch = 0.0F;
    public float droppedRotationRoll = 0.0F;
    public float droppedScale = 0.0F;

    // Projectile Position
    public float projectilePositionX = 0.0F;
    public float projectilePositionY = 0.0F;
    public float projectilePositionZ = 0.0F;
    public float projectileRotationYaw = 0.0F;
    public float projectileRotationPitch = 0.0F;
    public float projectileRotationRoll = 0.0F;
    public float projectileScale = 0.0F;

    // Fireball Position
    public float fireballPositionX = 0.0F;
    public float fireballPositionY = 0.0F;
    public float fireballPositionZ = 0.0F;
    public float fireballRotationYaw = 0.0F;
    public float fireballRotationPitch = 0.0F;
    public float fireballRotationRoll = 0.0F;
    public float fireballScale = 0.0F;

    // Fishing Rod Line Position
    public static boolean customRodLine = false;
    public float fishingLinePositionX = -0.36F;
    public float fishingLinePositionY = 0.03F;
    public float fishingLinePositionZ = 0.35F;
}
