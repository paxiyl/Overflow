package org.polyfrost.overflowanimations.config;

import com.google.gson.*;
import net.minecraft.client.Minecraft;
import org.polyfrost.overflowanimations.hooks.AnimationExportUtils;
import org.polyfrost.overflowanimations.hooks.PotionColors;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * OverflowAnimations configuration — OneConfig removed.
 * Settings are persisted to .minecraft/config/overflowanimations.json
 * All values are public (static where original was static) so every mixin
 * can read them exactly as before.
 */
public class OldAnimationsSettings {

    // ── 2D Dropped Items ─────────────────────────────────────────────────────
    public static boolean itemSprites = false;
    public static boolean itemSpritesColor = false;
    public static boolean spritesGlint = false;
    public static boolean rotationFix = true;

    // ── Smooth Sneaking ───────────────────────────────────────────────────────
    public static boolean smoothSneaking = true;
    public static boolean longerUnsneak = true;
    public static boolean smoothModelSneak = true;

    // ── Interaction ───────────────────────────────────────────────────────────
    public static boolean oldBlockhitting = true;
    public static boolean visualSwing = true;
    public static boolean punching = true;
    public static boolean punchingParticles = true;
    public static boolean adventurePunching = false;
    public static boolean adventureBlockHit = false;
    public static boolean adventureParticles = true;

    // ── Positions ─────────────────────────────────────────────────────────────
    public static boolean firstTransformations = true;
    public static boolean thirdTransformations = true;
    public static boolean fishingRodPosition = true;
    public static boolean firstPersonCarpetPosition = true;
    public static boolean thirdPersonCarpetPosition = true;
    public static boolean oldProjectiles = true;
    public static boolean oldArmPosition = true;
    public static boolean thirdPersonBlock = true;
    public static boolean oldXPOrbs = true;
    public static boolean oldPickup = true;

    // ── Enchantment Glint ─────────────────────────────────────────────────────
    public static boolean enchantmentGlint = true;
    public static boolean enchantmentGlintGui = false;

    // ── Item Changes ──────────────────────────────────────────────────────────
    public static boolean fishingStick = false;

    // ── HUD ───────────────────────────────────────────────────────────────────
    public static boolean oldHealth = true;
    /** 0=1.7  1=1.8  2=1.12+ */
    public static int debugCrosshairMode = 2;
    /** 0=1.7  1=1.8  2=Disable Background */
    public static int debugScreenMode = 1;
    /** 0=1.7  1=1.8  2=Disable Heads */
    public static int tabMode = 1;
    /** 0=None  1=1.7  2=1.8(With Glint)  3=1.8(Without Glint) */
    public static int armorDamageTintStyle = 3;

    // ── Item Switching ────────────────────────────────────────────────────────
    /** 0=Disabled  1=1.7  2=1.8 */
    public static int itemSwitchMode = 1;

    // ── Misc / Modern ─────────────────────────────────────────────────────────
    public static boolean modernPotColors = true;
    public static boolean enchantmentGlintNew = true;
    public static boolean rodBowGuiFix = true;
    public static boolean modernMovement = true;
    public static boolean modernBobbing = true;
    public static boolean modernDropSwing = true;
    public static boolean headYawFix = true;
    public static boolean funnyFidget = false;
    public static boolean modernBreak = true;
    public static boolean fireballModel = false;
    public static boolean damageTilt = false;

    // ── Re-equip Animation ────────────────────────────────────────────────────
    public static float reequipSpeed = 0.4F;
    public static boolean fixReequip = true;

    // ── Pickup Animation ──────────────────────────────────────────────────────
    public static boolean disablePickup = false;
    public static float pickupPosition = 0.0F;

    // ── Fishing Rod Line ──────────────────────────────────────────────────────
    public static boolean fixRod = true;
    public static float rodThickness = 0.0F;

    // ── Fixes, QOL, Tweaks ────────────────────────────────────────────────────
    public static boolean breakFix = false;
    public static boolean oldItemRotations = false;
    public static boolean potionGlint = false;
    public static boolean coloredBottles = false;
    public static boolean damageHeldItems = false;
    public static boolean damageCape = false;
    public static boolean modernDropSwingFix = true;
    public static boolean entityTransforms = true;
    public static boolean noHurtCam = false;

    // ── Fun ───────────────────────────────────────────────────────────────────
    public static boolean lunarBlockhit = false;
    public static boolean lunarPositions = false;
    public static boolean dinnerBoneMode = false;
    public static boolean dinnerBoneModeEntities = false;
    public static boolean wackyArms = false;
    public static boolean fakeBlockHit = false;

    // ── Custom Item Positions (global toggle + sliders) ───────────────────────
    public static boolean globalPositions = true;

    public static float itemPositionX = 0.0F;
    public static float itemPositionY = 0.0F;
    public static float itemPositionZ = 0.0F;
    public static float itemRotationYaw = 0.0F;
    public static float itemRotationPitch = 0.0F;
    public static float itemRotationRoll = 0.0F;
    public static float itemScale = 0.0F;

    public static float itemSwingSpeed = 0.0F;
    public static float itemSwingSpeedHaste = 0.0F;
    public static float itemSwingSpeedFatigue = 0.0F;
    /** 0=Default  1=Smart Scaling  2=Disable Translation */
    public static int swingSetting = 0;
    public static boolean ignoreHaste = false;
    public static boolean ignoreFatigue = false;

    // ── Internal state ────────────────────────────────────────────────────────
    public static boolean didTheFunnyDulkirThingElectricBoogaloo = false;

    // ── Advanced sub-settings (held as a separate plain object) ───────────────
    public static ItemPositionAdvancedSettings advancedSettings = new ItemPositionAdvancedSettings();

    // ── Singleton ─────────────────────────────────────────────────────────────
    public static final OldAnimationsSettings INSTANCE = new OldAnimationsSettings();

    // ── Persistence ───────────────────────────────────────────────────────────
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File configFile;

    private OldAnimationsSettings() {}

    /** Call once during mod init. Loads config from disk. */
    public void preload() {
        configFile = new File(new File(Minecraft.getMinecraft().mcDataDir, "config"),
                "overflowanimations.json");
        load();
        PotionColors.reloadColor();
    }

    // ── save / load ───────────────────────────────────────────────────────────

    private static JsonObject readFile() {
        if (configFile == null || !configFile.exists()) return new JsonObject();
        try (Reader r = new FileReader(configFile)) {
            return new JsonParser().parse(r).getAsJsonObject();
        } catch (Exception e) {
            return new JsonObject();
        }
    }

    public static void load() {
        JsonObject root = readFile();
        // Load static fields of OldAnimationsSettings
        applyJson(OldAnimationsSettings.class, null, root.has("main")
                ? root.getAsJsonObject("main") : root);
        // Load instance fields of advancedSettings
        if (root.has("advanced")) {
            applyJson(ItemPositionAdvancedSettings.class, advancedSettings,
                    root.getAsJsonObject("advanced"));
        }
        // Load static fields of ItemPositionAdvancedSettings
        if (root.has("advancedStatic")) {
            applyJson(ItemPositionAdvancedSettings.class, null,
                    root.getAsJsonObject("advancedStatic"));
        }
    }

    public static void save() {
        if (configFile == null) return;
        JsonObject root = new JsonObject();
        root.add("main", toJson(OldAnimationsSettings.class, null));
        root.add("advanced", toJson(ItemPositionAdvancedSettings.class, advancedSettings));
        root.add("advancedStatic", toJsonStatics(ItemPositionAdvancedSettings.class));
        try {
            if (!configFile.getParentFile().exists()) configFile.getParentFile().mkdirs();
            try (Writer w = new FileWriter(configFile)) {
                GSON.toJson(root, w);
            }
        } catch (Exception e) {
            System.err.println("[OverflowAnimations] Failed to save config: " + e.getMessage());
        }
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private static void applyJson(Class<?> clazz, Object instance, JsonObject obj) {
        for (Field f : clazz.getDeclaredFields()) {
            boolean isStatic = Modifier.isStatic(f.getModifiers());
            if (Modifier.isFinal(f.getModifiers())) continue;
            if (instance != null && isStatic) continue;   // skip statics when loading instance
            if (instance == null && !isStatic) continue;  // skip instance fields when loading statics
            if (!obj.has(f.getName())) continue;
            f.setAccessible(true);
            try {
                JsonElement el = obj.get(f.getName());
                Class<?> t = f.getType();
                Object target = isStatic ? null : instance;
                if (t == boolean.class || t == Boolean.class)    f.set(target, el.getAsBoolean());
                else if (t == int.class || t == Integer.class)   f.set(target, el.getAsInt());
                else if (t == float.class || t == Float.class)   f.set(target, el.getAsFloat());
                else if (t == double.class || t == Double.class) f.set(target, el.getAsDouble());
                else if (t == String.class)                       f.set(target, el.getAsString());
            } catch (Exception ignored) {}
        }
    }

    /** Serialize static fields of a class. */
    private static JsonObject toJson(Class<?> clazz, Object instance) {
        JsonObject obj = new JsonObject();
        for (Field f : clazz.getDeclaredFields()) {
            boolean isStatic = Modifier.isStatic(f.getModifiers());
            if (Modifier.isFinal(f.getModifiers())) continue;
            if (instance == null && !isStatic) continue;
            if (instance != null && isStatic) continue;
            f.setAccessible(true);
            try {
                Object val = isStatic ? f.get(null) : f.get(instance);
                if (val == null) continue;
                Class<?> t = f.getType();
                if (t == boolean.class || t == Boolean.class)    obj.addProperty(f.getName(), (Boolean) val);
                else if (t == int.class || t == Integer.class)   obj.addProperty(f.getName(), (Integer) val);
                else if (t == float.class || t == Float.class)   obj.addProperty(f.getName(), (Float) val);
                else if (t == double.class || t == Double.class) obj.addProperty(f.getName(), (Double) val);
                else if (t == String.class)                       obj.addProperty(f.getName(), (String) val);
            } catch (Exception ignored) {}
        }
        return obj;
    }

    private static JsonObject toJsonStatics(Class<?> clazz) {
        return toJson(clazz, null);
    }

    // ── GUI open helper (called by command) ───────────────────────────────────

    public void openGui() {
        Minecraft.getMinecraft().displayGuiScreen(
                new org.polyfrost.overflowanimations.gui.SimpleConfigGui());
    }
}
