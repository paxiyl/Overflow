package org.polyfrost.overflowanimations.gui;

import net.minecraft.client.gui.*;
import net.minecraft.client.resources.I18n;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;

/**
 * A minimal vanilla Minecraft GUI that shows all boolean toggles and a handful
 * of numeric fields for OverflowAnimations.  No external libraries required.
 *
 * Use /oam (or /overflowanimations) to open it in-game.
 *
 * Layout: scrollable list of toggle buttons, two columns.
 * Changes are saved immediately to disk when the GUI is closed.
 */
public class SimpleConfigGui extends GuiScreen {

    private static final int BUTTON_W = 200;
    private static final int BUTTON_H = 20;
    private static final int PAD = 4;

    // We list every boolean setting as a label/field pair.
    private static final String[][] BOOLEANS = {
        // label, fieldName (must be a public static boolean in OldAnimationsSettings)
        {"2D Dropped Items",                   "itemSprites"},
        {"1.7 Item Sprite Colors",             "itemSpritesColor"},
        {"Remove Glint From Sprites",          "spritesGlint"},
        {"Rotation Fix (sprites)",             "rotationFix"},
        {"1.7 Smoother Sneaking",              "smoothSneaking"},
        {"1.7 Longer Unsneak",                 "longerUnsneak"},
        {"1.7 Third-Person Sneaking",          "smoothModelSneak"},
        {"1.7 Block-Hitting Animation",        "oldBlockhitting"},
        {"1.7 Miss Penalty Swing",             "visualSwing"},
        {"1.7 Punching During Usage",          "punching"},
        {"1.7 Punch-During-Usage Particles",   "punchingParticles"},
        {"1.7 First-Person Transforms",        "firstTransformations"},
        {"1.7 Third-Person Transforms",        "thirdTransformations"},
        {"1.7 Fishing Rod Position",           "fishingRodPosition"},
        {"1.7 First-Person Carpet Position",   "firstPersonCarpetPosition"},
        {"1.7 Third-Person Carpet Position",   "thirdPersonCarpetPosition"},
        {"1.7 Projectile Transforms",          "oldProjectiles"},
        {"1.7 Third-Person Arm Block",         "oldArmPosition"},
        {"1.7 Third-Person Sword Block",       "thirdPersonBlock"},
        {"1.7 XP Orbs Position",               "oldXPOrbs"},
        {"1.7 Pickup Animation",               "oldPickup"},
        {"1.7 Enchantment Glint",              "enchantmentGlint"},
        {"1.7 GUI Enchantment Glint",          "enchantmentGlintGui"},
        {"1.7 Fishing Stick Texture",          "fishingStick"},
        {"1.7 Health Bar Flashing",            "oldHealth"},
        {"1.20+ Potion Colors",                "modernPotColors"},
        {"1.15+ Armor Enchantment Glint",      "enchantmentGlintNew"},
        {"1.9+ Bow/Rod GUI Animation",         "rodBowGuiFix"},
        {"1.15+ Backwards Walk",               "modernMovement"},
        {"1.14+ View Bobbing",                 "modernBobbing"},
        {"1.15+ Drop Item Arm Swing",          "modernDropSwing"},
        {"1.15+ Head Yaw Fix",                 "headYawFix"},
        {"1.9+ Item Use Cooldown Anim",        "funnyFidget"},
        {"1.19+ Block Breaking Anim",          "modernBreak"},
        {"1.14+ Fireball Model",               "fireballModel"},
        {"1.19.4+ Damage Tilt",               "damageTilt"},
        {"Only Re-equip On Slot Switch",       "fixReequip"},
        {"Disable Item Pickup Anim",           "disablePickup"},
        {"Rod Line Based on FOV",              "fixRod"},
        {"Block Breaking Fixes",               "breakFix"},
        {"Disable Hand View Sway",             "oldItemRotations"},
        {"Disable Potion Glint",               "potionGlint"},
        {"Colored Potion Bottles",             "coloredBottles"},
        {"Damage Tint Held Items",             "damageHeldItems"},
        {"Damage Tint Capes",                  "damageCape"},
        {"Disable Drop Swing In Chests",       "modernDropSwingFix"},
        {"Disable Entity 3P Transforms",       "entityTransforms"},
        {"Disable Hurt Camera Shake",          "noHurtCam"},
        {"Lunar Block-Hit Position",           "lunarBlockhit"},
        {"Lunar Item Positions",               "lunarPositions"},
        {"Dinnerbone Mode (Player)",           "dinnerBoneMode"},
        {"Dinnerbone Mode (All Entities)",     "dinnerBoneModeEntities"},
        {"Alpha/Indev Wavy Arms",              "wackyArms"},
        {"Allow Clicking While Using Item",    "fakeBlockHit"},
        {"Global Item Position Toggle",        "globalPositions"},
        {"Adventure Mode Punching",            "adventurePunching"},
        {"Adventure Mode Block Hit",           "adventureBlockHit"},
        {"Adventure Mode Particles",           "adventureParticles"},
        {"Ignore Haste Swing Speed",           "ignoreHaste"},
        {"Ignore Fatigue Swing Speed",         "ignoreFatigue"},
    };

    // scroll offset in pixels
    private int scrollOffset = 0;
    private int totalContentHeight;

    @Override
    public void initGui() {
        // Buttons are built dynamically in drawScreen / mouse clicks
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        // Title
        drawCenteredString(fontRendererObj, "OverflowAnimations Config", width / 2, 8, 0xFFFFFF);
        drawString(fontRendererObj, "Scroll: Mouse Wheel | Close: ESC (saves)", 4, height - 12, 0xAAAAAA);

        int cols = 2;
        int colW = (width - PAD * (cols + 1)) / cols;
        int startY = 24 - scrollOffset;

        for (int i = 0; i < BOOLEANS.length; i++) {
            String label = BOOLEANS[i][0];
            String field = BOOLEANS[i][1];
            boolean value = getBoolean(field);

            int col = i % cols;
            int row = i / cols;
            int bx = PAD + col * (colW + PAD);
            int by = startY + row * (BUTTON_H + PAD);

            if (by + BUTTON_H < 20 || by > height - 20) continue;

            int color = value ? 0x0055AA : 0x444444;
            drawRect(bx, by, bx + colW, by + BUTTON_H, 0xFF000000 | color);
            drawRect(bx + 1, by + 1, bx + colW - 1, by + BUTTON_H - 1,
                    0xFF000000 | (value ? 0x0077CC : 0x555555));
            drawString(fontRendererObj,
                    label + ": " + (value ? "\u00a7aON" : "\u00a7cOFF"),
                    bx + 4, by + (BUTTON_H - 8) / 2, 0xFFFFFF);
        }

        totalContentHeight = ((BOOLEANS.length + 1) / cols) * (BUTTON_H + PAD) + 24;
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) {
        if (button != 0) return;
        int cols = 2;
        int colW = (width - PAD * (cols + 1)) / cols;
        int startY = 24 - scrollOffset;

        for (int i = 0; i < BOOLEANS.length; i++) {
            String field = BOOLEANS[i][1];
            int col = i % cols;
            int row = i / cols;
            int bx = PAD + col * (colW + PAD);
            int by = startY + row * (BUTTON_H + PAD);

            if (mouseX >= bx && mouseX <= bx + colW && mouseY >= by && mouseY <= by + BUTTON_H) {
                toggleBoolean(field);
                return;
            }
        }
    }

    @Override
    public void handleMouseInput() throws java.io.IOException {
        super.handleMouseInput();
        int scroll = org.lwjgl.input.Mouse.getEventDWheel();
        if (scroll != 0) {
            scrollOffset -= Integer.signum(scroll) * 20;
            int maxScroll = Math.max(0, totalContentHeight - (height - 40));
            scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
        }
    }

    @Override
    public void onGuiClosed() {
        OldAnimationsSettings.save();
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    // ── reflection helpers ────────────────────────────────────────────────────

    private static boolean getBoolean(String fieldName) {
        try {
            return OldAnimationsSettings.class.getField(fieldName).getBoolean(null);
        } catch (Exception e) {
            return false;
        }
    }

    private static void toggleBoolean(String fieldName) {
        try {
            java.lang.reflect.Field f = OldAnimationsSettings.class.getField(fieldName);
            f.setBoolean(null, !f.getBoolean(null));
        } catch (Exception ignored) {}
    }
}
