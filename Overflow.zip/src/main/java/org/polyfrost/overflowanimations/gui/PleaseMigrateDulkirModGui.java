package org.polyfrost.overflowanimations.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.polyfrost.overflowanimations.OverflowAnimations;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;
import org.polyfrost.overflowanimations.hooks.AnimationExportUtils;

/**
 * Replacement for OneConfig-based PleaseMigrateDulkirModGui.
 * Uses vanilla GuiScreen — no external libraries needed.
 */
public class PleaseMigrateDulkirModGui extends GuiScreen {

    private GuiButton transferButton;
    private GuiButton cancelButton;
    private boolean confirmCancel = false;

    @Override
    public void initGui() {
        int cx = width / 2;
        int cy = height / 2;
        transferButton = new GuiButton(0, cx - 110, cy + 30, 100, 20, "Transfer");
        cancelButton   = new GuiButton(1, cx + 10,  cy + 30, 100, 20, "Cancel");
        buttonList.add(transferButton);
        buttonList.add(cancelButton);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int cx = width / 2;
        int cy = height / 2;
        drawCenteredString(fontRendererObj, "OverflowAnimations", cx, cy - 50, 0xFFFFFF);
        drawCenteredString(fontRendererObj,
                "OverflowAnimations now replaces DulkirMod's animations feature.", cx, cy - 20, 0xDDDDDD);
        drawCenteredString(fontRendererObj,
                "Would you like to import your DulkirMod config?", cx, cy, 0xDDDDDD);
        drawCenteredString(fontRendererObj,
                "(You can transfer your config later via /oam)", cx, cy + 15, 0xAAAAAA);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 0) {
            markAsViewed();
            AnimationExportUtils.transferDulkirConfig();
            mc.displayGuiScreen(null);
        } else if (button.id == 1) {
            if (!confirmCancel) {
                confirmCancel = true;
                cancelButton.displayString = "Confirm";
            } else {
                markAsViewed();
                mc.displayGuiScreen(null);
            }
        }
    }

    private void markAsViewed() {
        OverflowAnimations.doTheFunnyDulkirThing = false;
        OldAnimationsSettings.didTheFunnyDulkirThingElectricBoogaloo = true;
        OldAnimationsSettings.save();
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
