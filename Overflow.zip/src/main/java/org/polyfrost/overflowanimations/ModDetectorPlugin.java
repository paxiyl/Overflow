package org.polyfrost.overflowanimations;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.MalformedJsonException;
import net.minecraft.launchwrapper.Launch;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ModDetectorPlugin implements IFMLLoadingPlugin {

    public ModDetectorPlugin() {
        try {
            File modsFolder = new File(Launch.minecraftHome, "mods");
            File[] modFolder = modsFolder.listFiles((dir, name) -> name.endsWith(".jar"));
            if (modFolder != null) {
                final JsonParser PARSER = new JsonParser();
                File oldFile = null;
                for (File file : modFolder) {
                    try {
                        try (ZipFile mod = new ZipFile(file)) {
                            ZipEntry entry = mod.getEntry("mcmod.info");
                            if (entry != null) {
                                try (InputStream inputStream = mod.getInputStream(entry)) {
                                    byte[] availableBytes = new byte[inputStream.available()];
                                    inputStream.read(availableBytes, 0, inputStream.available());
                                    JsonObject modInfo = PARSER.parse(new String(availableBytes)).getAsJsonArray().get(0).getAsJsonObject();
                                    if (!modInfo.has("modid") || !modInfo.has("version")) {
                                        continue;
                                    }

                                    String modid = modInfo.get("modid").getAsString();
                                    if (modid.equals("sk1er_old_animations")) {
                                        oldFile = file;
                                        break;
                                    }
                                }
                            }
                        }
                    } catch (MalformedJsonException | IllegalStateException ignored) {
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (oldFile != null) {
                    System.err.println("[OverflowAnimations] ERROR: Sk1er Old Animations is also installed: " + oldFile.getAbsolutePath());
                    if (oldFile.delete()) {
                        System.err.println("[OverflowAnimations] Removed the conflicting Sk1er Old Animations jar. Please restart Minecraft.");
                    } else {
                        oldFile.deleteOnExit();
                        System.err.println("[OverflowAnimations] Could not remove the conflicting jar automatically. It will be removed on exit if possible.");
                    }
                    // Stop before both animation mods can initialise and conflict.
                    System.exit(1);
                }
            }

        } catch (Exception ignored) {

        }
    }

    @Override
    public String[] getASMTransformerClass() {
        return new String[0];
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> map) {

    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}