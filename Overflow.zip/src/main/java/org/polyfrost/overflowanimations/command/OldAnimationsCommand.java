package org.polyfrost.overflowanimations.command;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.client.Minecraft;
import org.polyfrost.overflowanimations.config.OldAnimationsSettings;
import org.polyfrost.overflowanimations.gui.SimpleConfigGui;

import java.util.Collections;
import java.util.List;

/**
 * /overflowanimations — opens the config GUI in-game.
 * Aliases: /oam  /oldanimations  /animations
 *
 * OneConfig CommandManager replaced with a plain Forge ClientCommandHandler command.
 */
public class OldAnimationsCommand extends CommandBase {

    @Override
    public String getCommandName() {
        return "overflowanimations";
    }

    @Override
    public List<String> getCommandAliases() {
        return java.util.Arrays.asList("oam", "oldanimations", "animations");
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/overflowanimations";
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) {
        Minecraft.getMinecraft().displayGuiScreen(new SimpleConfigGui());
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }
}
