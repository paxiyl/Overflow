package org.polyfrost.overflowanimations.mixin.compat;

import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * DulkirMod compat mixin.
 * OneConfig dependency removed — this mixin no longer extends Config.
 * The UI-lock feature (addDependency) is dropped since we have no OneConfig GUI anyway.
 */
@Pseudo
@Mixin(targets = "dulkirmod.config.DulkirConfig", remap = false)
public class DulkirConfigMixin {
    // No-op: previously locked DulkirMod's custom animation sliders via OneConfig.
    // Without OneConfig there is nothing to lock in the GUI.
}
